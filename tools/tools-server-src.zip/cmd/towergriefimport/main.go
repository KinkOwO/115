package main

import (
	"dfolan/internal/catalog"
	"dfolan/internal/catalog/pvf"
	"encoding/json"
	"flag"
	"log"
	"os"
)

func main() {
	source := flag.String("source", "../client-build/Script.inner.pvf", "current source PVF")
	output := flag.String("output", "configs/dungeons.tower-of-grief-maps.json", "source-matched tower overlay")
	flag.Parse()
	a, err := pvf.LoadArchive(pvf.Options{Path: *source, MaxBytes: 1024 * 1024 * 1024})
	if err != nil {
		log.Fatal(err)
	}
	overlay, err := catalog.ImportTowerGriefOverlay(a)
	if err != nil {
		log.Fatal(err)
	}
	b, err := json.Marshal(overlay)
	if err != nil {
		log.Fatal(err)
	}
	if err := os.WriteFile(*output, b, 0644); err != nil {
		log.Fatal(err)
	}
	log.Printf("wrote %d layers and %d maps to %s", len(overlay.Layers), len(overlay.Maps), *output)
}
