package main

import (
	"context"
	"dfolan/internal/database"
	"dfolan/internal/dungeon"
	"dfolan/internal/game/protocol"
	"dfolan/internal/legion"
	"dfolan/internal/workflow"
	"fmt"
	"log"
	"time"
)

func (w *worldSession) resetCards() {
	w.cardPlan = nil
	w.cardReceipt = nil
	w.cardScrolled = false
	w.cardLayoutSent = false
	w.cardAutoPickAt = time.Time{}
}
func (w *worldSession) cardsReady() error {
	if w == nil || w.loot == nil || w.activeDungeon == nil || !w.activeDungeon.Completed() || !w.resultSent || w.cardPlan == nil || w.cardPlan.Run != w.activeDungeon.RunID {
		return fmt.Errorf("cards before owned settlement")
	}
	return nil
}
func (w *worldSession) cardSnapshot() []byte {
	index := -1
	if w.cardReceipt != nil {
		index = int(w.cardReceipt.Index)
	}
	p, _ := protocol.CardSelected(index)
	return p
}
func (w *worldSession) cardStage(id uint16, p []byte) ([]outboundPacket, error) {
	if e := w.cardsReady(); e != nil {
		return nil, e
	}
	if len(p) != 0 {
		return nil, fmt.Errorf("card stage has unexpected body")
	}
	if id == 69 {
		return []outboundPacket{{"card_scroll_ack", 1, 69, []byte{1}}}, nil
	}
	if id != 70 || !w.cardScrolled {
		return nil, fmt.Errorf("card layout before scroll")
	}
	return []outboundPacket{{"card_layout_ack", 1, 70, protocol.CardLayout()}}, nil
}
func (w *worldSession) grantFreeCard(index byte) ([]outboundPacket, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	role, receipt, _, e := (&workflow.LootService{Store: w.store, Loot: w.loot}).PickCard(ctx, w.role, w.activeDungeon, *w.cardPlan, index)
	if e != nil {
		return nil, e
	}
	w.role = role
	bag, e := w.items.Bootstrap(workflow.InventoryRole(role))
	if e != nil {
		return nil, e
	}
	w.cardReceipt = &receipt
	w.cardAutoPickAt = time.Time{}
	return []outboundPacket{{"card_inventory_committed", 0, 13, bag}, {"card_selection_ack", 1, 71, w.cardSnapshot()}}, nil
}

// autoPickSettlementCard 在「翻牌布局已发出、玩家一直没选」时替他选**第一张免费牌**。
//
// 与手动选牌及退出结算共用同一领取事务（grantFreeCard(0)）；仅从布局发出开始计时，
// 重复请求不会延长等待，已领过（cardReceipt != nil）就不再动。
//
// 这套机制原本只给黑鸦开（判据写在副本号上），其它副本 —— 蔚蓝号也不例外 ——
// 倒计时结束后服务端什么都不发，客户端就停在「一张都没翻」的状态
// （业主实机 2026-10-04）。翻牌界面本来就是同一套 69/70/71，所以这里放开到
// **所有已结算的副本**；黑鸦那两个事件名保留（有测试与日志在依赖它们）。
func (w *worldSession) autoPickSettlementCard(now time.Time) ([]outboundPacket, error) {
	if w == nil || w.cardAutoPickAt.IsZero() || now.Before(w.cardAutoPickAt) {
		return nil, nil
	}
	if w.activeDungeon == nil || w.cardReceipt != nil || !w.cardLayoutSent || w.cardsReady() != nil {
		w.cardAutoPickAt = time.Time{}
		return nil, nil
	}
	packets, err := w.grantFreeCard(0)
	if err != nil {
		// 未提交则保留奖单，已提交但通知失败则幂等重取；满包不吞奖。
		w.cardAutoPickAt = now.Add(5 * time.Second)
		return nil, err
	}
	if w.activeDungeon.Definition.ID == blackPurgatorySquadDungeon {
		packets[0].Name = "黑鸦自动翻牌背包同步"
		packets[1].Name = "黑鸦自动翻牌选牌确认"
	}
	return packets, nil
}
func (w *worldSession) cardPick(p []byte) ([]outboundPacket, error) {
	if e := w.cardsReady(); e != nil {
		return nil, e
	}
	r, e := protocol.DecodeCardSelection(p)
	if e != nil {
		return nil, e
	}
	if !w.cardLayoutSent {
		return nil, fmt.Errorf("card choice before reveal")
	}
	if r.Side != 0 {
		return nil, fmt.Errorf("paid card policy is not enabled")
	}
	return w.grantFreeCard(r.Index)
}
func (w *worldSession) settlementExit(p []byte) (*dungeon.Session, []outboundPacket, error) {
	r, e := protocol.DecodeSettlementExit(p)
	if e != nil {
		return nil, nil, e
	}
	// [ISPINS-ARENA-BOSS] 伊斯大陆的 CMD72 全部不走通用翻牌/结算：官服 s4
	// 整场没有一帧 69/70/71（阶段奖励由 N2256/N2252 承载），撤退休退
	// （source=0）更发生在副本未完成时。回城复用 leaveDungeon（回到进本前
	// 位置=待机区），弃用 42 回执、只发 ACK72；主循环按 settlement_exit_ack
	// 清 activeDungeon。不保持选图（option 1 在军团流程没有「选图」语义）。
	// 撤退不算通关：run.cleared 不动，玩家重新 CMD2043 开战时官服语义本就
	// 是整场作废重开。
	if w.ispins != nil && w.activeDungeon != nil {
		ack := outboundPacket{"settlement_focus_ack", 1, 72, protocol.SettlementExitSuccess(r)}
		if r.State == 2 {
			// Focus only updates the button selection. Naming this as an exit
			// triggers main.go's post-send activeDungeon/card cleanup, so the
			// subsequent state1 request loses its owned Ispins settlement.
			return nil, []outboundPacket{ack}, nil
		}
		route, e := w.leaveDungeon()
		if e != nil {
			return nil, nil, e
		}
		w.selectingDungeon = false
		ack.Name = "settlement_exit_ack"
		if w.ispins.finalDone && w.ispins.storyFinished {
			w.ispinsRepeatPending = true
			w.ispins = nil
		}
		return nil, append([]outboundPacket{ack}, route[1:]...), nil
	}
	// 维纳斯阶段本的 CMD72 全部不走通用翻牌/结算。形状：ACK72 后走
	// leaveDungeon 回维纳斯待机区，主循环按 settlement_exit_ack 清
	// activeDungeon。run 复位为全新未选状态（不再作废——2026-10-04 13:33
	// 实机：作废后客户端带着已选难度残留，回城自动弹难度窗、进入地下城/
	// 更改难度全被静默拒绝，作战窗口状态机卡死），序列末尾垫等待态 N2655
	// 让客户端作战窗口从「未选难度」重启。DGN 声明 [no giveup panalty]，
	// 无惩罚语义只影响未实现的次数账本。
	if w.venus != nil && w.activeDungeon != nil && legion.IsVenusStageDungeon(w.activeDungeon.Definition.ID) {
		ack := outboundPacket{"settlement_focus_ack", 1, 72, protocol.SettlementExitSuccess(r)}
		if r.State == 2 {
			// Focus only updates the button selection; keep the run owned.
			return nil, []outboundPacket{ack}, nil
		}
		route, e := w.leaveDungeon()
		if e != nil {
			return nil, nil, e
		}
		w.selectingDungeon = false
		ack.Name = "settlement_exit_ack"
		if w.venus.finalDone {
			// 通关视频后的返回城镇：run 已结束——末尾发关闭态 N2655（State0，
			// 兜底保证右上角面板与遗物显示消失；视频恢复时的 leave 态已发过）
			// 并作废 run：Open 不得再进图，重新开团走门（CMD2043）。
			closed := outboundPacket{"venus_info_closed", 0, legion.NotiVenusInfo, legion.VenusClosedInfo()}
			w.venus = nil
			return nil, append(append([]outboundPacket{ack}, route[1:]...), closed), nil
		}
		w.venus.resetRun()
		plan := append(append([]outboundPacket{ack}, route[1:]...),
			outboundPacket{"venus_info_waiting", 0, legion.NotiVenusInfo, legion.VenusWaitingInfo()})
		return nil, plan, nil
	}
	if e = w.cardsReady(); e != nil {
		return nil, nil, e
	}
	ack := outboundPacket{"settlement_focus_ack", 1, 72, protocol.SettlementExitSuccess(r)}
	if r.State == 2 {
		return nil, []outboundPacket{ack}, nil
	}
	// Routing follows the decoded request, independently of the ACK envelope.
	w.selectingDungeon = r.Option == 1
	// Preflight routing before granting an automatic unclaimed free card.
	var pending *dungeon.Session
	var route []outboundPacket
	switch r.Option {
	case 0:
		// dstr 479 "Restart the dungeon.": reopen the run that was just
		// settled, behind the dungeon-select head. See restartDungeon.
		pending, route, e = w.restartDungeon()
	case 1:
		copy := *w
		copy.activeDungeon = nil
		route, e = copy.dungeonGate(make([]byte, 8))
	case protocol.SettlementExitSeamless:
		// 无缝续刷（CMD72 选项 5）。复用 restartDungeon —— 它已经是
		// 「ACK15 + NOTI27 + 入场序列」的形状，正是这份修复需要的顺序
		// （两份外部文档在「要不要发 NOTI27」上互相矛盾，较晚的那份明确纠正
		// 了较早的「省略 NOTI27」，理由是该清理函数同时负责卸载
		// onExitModule_SeamlessLoading 的旧地图状态）。
		// ACK 里的 option 原样保留 5（SettlementExitSuccess 用 r.Option），
		// 客户端据此走无缝重置路径而不是普通重开。
		//
		// 准入：只有**已通关**的那一次可以借它续刷；未通关时这个选项
		// 不该出现，出现也拒绝，避免把未完成的挑战重开成新一轮。
		if w.activeDungeon == nil || !w.activeDungeon.Completed() {
			return nil, nil, fmt.Errorf("seamless rechallenge before a committed clear")
		}
		pending, route, e = w.restartDungeon()
	case 2, 3:
		// Current scenario option3 is "Start Next Quest". A town objective
		// returns to the owned town; preserve the active quest for NPC handling.
		route, e = w.leaveDungeon()
		if e == nil {
			route = route[1:]
		}
	}
	if e != nil {
		return nil, nil, e
	}
	var plan []outboundPacket
	if w.cardReceipt == nil {
		plan, e = w.grantFreeCard(0)
		if e != nil {
			if w.activeDungeon.Definition.ID != blackPurgatorySquadDungeon || (r.Option != 2 && r.Option != 3) {
				return nil, nil, e
			}
			// 黑鸦奖单已在通关事务落盘，未领取时由重登恢复。满包或暂时
			// 无法发奖不能阻断回城；不发送领取成功，也不删除待领奖单。
			log.Printf("黑鸦翻牌暂未领取，保留奖单等待重登补发：角色=%d 挑战=%s 错误=%v", w.role.ID, w.cardPlan.Run, e)
			plan = nil
		}
	}
	ack.Name = "settlement_exit_ack"
	plan = append(plan, ack)
	plan = append(plan, route...)
	return pending, plan, nil
}

// restartDungeon reopens the run that has just been settled. The settlement
// panel's option 0 is dstr 479 "Restart the dungeon." - the same map as a
// fresh run, not a return to town (option 2 is dstr 481, "Return to town.").
//
// The client is still sitting on the settlement panel when it sends CMD 72,
// and the native handler has already torn the instance module down; an entry
// sequence pushed straight back arrives at a dismantled scene and takes the
// client out with 0xC0000005 (live 20260922T193325, the only option 0 of that
// session). The post-clear "next story dungeon" gate (CMD 2062) hit exactly
// this and solved it by raising the client to the dungeon-select UI first -
// ACK 15 + NOTI 27 - and only then replaying the CMD 16 entry sequence. This
// reuses that shape with the finished run's own id and maze quest, so "again"
// is a direct reopen and never routes through the town the way leaveDungeon
// does.
func (w *worldSession) restartDungeon() (*dungeon.Session, []outboundPacket, error) {
	if w == nil || w.dungeons == nil || w.role.ID == 0 {
		return nil, nil, fmt.Errorf("dungeon catalog or character unavailable")
	}
	old := w.activeDungeon
	if old == nil {
		return nil, nil, fmt.Errorf("retry without an active dungeon")
	}
	if old.Definition.ID == blackPurgatorySquadDungeon {
		return nil, nil, fmt.Errorf("黑鸦挑战结束，请返回大厅重新创建队伍")
	}
	if old.Definition.Tower != nil {
		return nil, nil, fmt.Errorf("%s tower does not allow settlement retry", old.Definition.Tower.Key)
	}
	copy := *w
	copy.activeDungeon = nil
	sel := protocol.DungeonSelection{ID: old.Definition.ID, Party: 65535, Quest: uint32(old.Maze.Quest)}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	// The same entry gate the ordinary selection applies, minus its town-only
	// check: the character is inside a run, so there is no PVF [dungeon gate]
	// area under its feet to stand on.
	if w.fatigue != nil && !old.Definition.NoFatigue && w.fatigue.EnterCostFor(old.Definition.ID) > 0 {
		fp, err := w.fatigue.State(ctx, w.account, w.role.ID, time.Now())
		if err != nil {
			return nil, nil, err
		}
		if fp.Used >= fp.Limit {
			return nil, nil, database.ErrFatigueExhausted
		}
	}
	accepted, e := copy.acceptedQuestIDs(ctx)
	if e != nil {
		return nil, nil, e
	}
	s, e := dungeon.Select(*copy.dungeons, sel, copy.level, accepted)
	if e != nil {
		return nil, nil, e
	}
	entry, e := copy.dungeonEntryPlan(context.Background(), "dungeon_select_ack", 16, sel, s)
	if e != nil {
		return nil, nil, e
	}
	return s, append(dungeonSelectionHead(), entry...), nil
}
