package main

import (
	"dfolan/internal/catalog"
	"dfolan/internal/game/protocol"
	"fmt"
	"math"
)

func odysseySourceBooster(item catalog.LootItem) (BoosterDefinition, error) {
	def := BoosterDefinition{Template: item.ID, Type: item.StackableType}
	inside := false
	cells := item.Script.Cells
	for i := 0; i < len(cells); i++ {
		if cells[i].Text == "[booster info]" {
			inside = true
			continue
		}
		if cells[i].Text == "[/booster info]" {
			inside = false
		}
		if !inside || cells[i].Type != 3 {
			continue
		}
		tag := cells[i].Text
		if tag != "[etc]" && tag != "[equipment]" && tag != "[avatar]" && tag != "[stackable]" && tag != "[creature]" {
			return def, fmt.Errorf("奥德赛礼包奖励分组未支持：%s", tag)
		}
		var nums []uint32
		for i++; i < len(cells) && cells[i].Text != "[/"+tag[1:]; i++ {
			if cells[i].Type != 0 || cells[i].Value <= 0 {
				return def, fmt.Errorf("奥德赛礼包奖励数值无效")
			}
			nums = append(nums, uint32(cells[i].Value))
		}
		if len(nums) < 4 || (len(nums)-1)%3 != 0 {
			return def, fmt.Errorf("奥德赛礼包奖励表长度无效")
		}
		pool := BoosterRewardPool{DrawCount: nums[0]}
		for n := 1; n < len(nums); n += 3 {
			pool.Candidates = append(pool.Candidates, BoosterRewardCandidate{Template: nums[n], Weight: nums[n+1], Count: nums[n+2]})
		}
		def.Pools = append(def.Pools, pool)
	}
	if len(def.Pools) == 0 {
		return def, fmt.Errorf("奥德赛礼包缺少原版奖励表：%d", item.ID)
	}
	return def, nil
}

// 使用原版类别和物品数量校验选择，零选项整包发放不依赖缺失的通用目录投影。
func odysseySourceSelection(script catalog.ScriptRecord, req protocol.BoosterUseRequest) ([]protocol.BoosterGrantedItem, error) {
	count := -1
	category, selected := false, false
	var candidates []protocol.BoosterGrantedItem
	cells := script.Cells
	for i := 0; i < len(cells); i++ {
		t := cells[i]
		if t.Text == "[booster selection num]" && i+1 < len(cells) {
			count = int(cells[i+1].Value)
		}
		if t.Text == "[booster select category]" && i+2 < len(cells) {
			a, b := cells[i+1].Value, cells[i+2].Value
			category = a >= 0 && a <= 255 && b >= 0 && b <= 255 && uint16(a)|uint16(b)<<8 == req.Category
			selected = selected || category
		}
		if t.Text == "[/booster select category]" {
			category = false
		}
		if !category || t.Text != "[equipment]" && t.Text != "[stackable]" {
			continue
		}
		for i++; i < len(cells) && cells[i].Type != 3; i += 2 {
			if i+1 >= len(cells) || cells[i].Type != 0 || cells[i+1].Type != 0 || cells[i].Value <= 0 || cells[i+1].Value <= 0 {
				return nil, fmt.Errorf("奥德赛礼盒奖励格式无效")
			}
			n := uint64(cells[i+1].Value) * uint64(req.Amount)
			if n > math.MaxUint32 {
				return nil, fmt.Errorf("奥德赛礼盒奖励数量溢出")
			}
			candidates = append(candidates, protocol.BoosterGrantedItem{Template: uint32(cells[i].Value), Count: uint32(n)})
		}
		i--
	}
	if !selected || count < 0 || len(candidates) == 0 || len(req.AvatarOptions) != 0 {
		return nil, fmt.Errorf("奥德赛礼盒类别无效")
	}
	if count == 0 {
		if len(req.Selections) != 0 {
			return nil, fmt.Errorf("整包奖励不能指定自选项")
		}
		return candidates, nil
	}
	if len(req.Selections) != count {
		return nil, fmt.Errorf("奥德赛礼盒选择数量无效")
	}
	seen := map[uint32]bool{}
	var rewards []protocol.BoosterGrantedItem
	for _, id := range req.Selections {
		if seen[id] {
			return nil, fmt.Errorf("奥德赛礼盒选择重复")
		}
		seen[id] = true
		found := false
		for _, candidate := range candidates {
			if candidate.Template == id {
				rewards = append(rewards, candidate)
				found = true
				break
			}
		}
		if !found {
			return nil, fmt.Errorf("所选物品不属于原版礼盒类别")
		}
	}
	return rewards, nil
}
