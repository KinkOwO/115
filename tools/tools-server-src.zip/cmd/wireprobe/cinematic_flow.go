package main

import (
	"context"
	"dfolan/internal/game/protocol"
	"dfolan/internal/storage"
	"encoding/json"
	"fmt"
	"time"
)

func cinematicRestore(raw json.RawMessage) ([]byte, error) {
	var state struct {
		Scenes []uint16 `json:"cinematic_skipped"`
	}
	if err := json.Unmarshal(raw, &state); err != nil {
		return nil, err
	}
	return protocol.CinematicSkippedScenes(state.Scenes)
}

func storyDigestRestore(raw json.RawMessage) ([]byte, error) {
	var state struct {
		Level uint32 `json:"story_digest_level"`
	}
	if err := json.Unmarshal(raw, &state); err != nil {
		return nil, err
	}
	return protocol.StoryDigestLevel(state.Level)
}

// 原生 0x1444f6338 将当前等级记入回顾状态，随后发送无正文 CMD1438。
// 服务端从角色存档取等级，不接收客户端任意指定的等级或章节编号。
func storyDigestUpdate(store *storage.Store, w *worldSession, p []byte) (uint32, error) {
	if store == nil || w == nil || w.role.ID == 0 || w.role.AccountID != w.account {
		return 0, fmt.Errorf("剧情回顾更新缺少有效角色")
	}
	if len(p) != 0 {
		return 0, fmt.Errorf("剧情回顾更新应为无正文请求")
	}
	var state struct {
		Level uint32 `json:"level"`
	}
	if err := json.Unmarshal(w.role.State, &state); err != nil {
		return 0, err
	}
	if state.Level == 0 || state.Level > 0x7fffffff {
		return 0, fmt.Errorf("剧情回顾更新的角色等级无效")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	saved, _, err := store.CommitCharacterEvent(ctx, w.account, w.role.ID, w.role.ConfigVersion, fmt.Sprintf("story-digest-level:%d", state.Level), "story-digest-v1", func(current storage.Character) (json.RawMessage, json.RawMessage, error) {
		var latest struct {
			Level     uint32 `json:"level"`
			ReadLevel uint32 `json:"story_digest_level"`
		}
		if err := json.Unmarshal(current.State, &latest); err != nil {
			return nil, nil, err
		}
		if latest.Level != state.Level {
			return nil, nil, fmt.Errorf("剧情回顾更新时角色等级发生变化")
		}
		var fields map[string]json.RawMessage
		if err := json.Unmarshal(current.State, &fields); err != nil {
			return nil, nil, err
		}
		level := max(latest.ReadLevel, latest.Level)
		receipt, err := json.Marshal(level)
		if err != nil {
			return nil, nil, err
		}
		fields["story_digest_level"] = receipt
		raw, err := json.Marshal(fields)
		return raw, receipt, err
	})
	if err != nil {
		return 0, err
	}
	saved.WireID = w.role.WireID
	w.role = saved
	return state.Level, nil
}

func synopsisRead(store *storage.Store, w *worldSession, p []byte) ([]byte, error) {
	if store == nil || w == nil || w.role.ID == 0 || w.role.AccountID != w.account {
		return nil, fmt.Errorf("剧情摘要已读请求缺少有效角色")
	}
	id, err := protocol.DecodeSynopsisRead(p)
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	saved, _, err := store.CommitCharacterEvent(ctx, w.account, w.role.ID, w.role.ConfigVersion, fmt.Sprintf("synopsis-read:%d", id), "synopsis-read-v1", func(current storage.Character) (json.RawMessage, json.RawMessage, error) {
		var fields map[string]json.RawMessage
		if err := json.Unmarshal(current.State, &fields); err != nil {
			return nil, nil, err
		}
		if fields == nil {
			fields = make(map[string]json.RawMessage)
		}
		var ids []uint32
		if raw := fields["synopsis_read"]; raw != nil {
			if err := json.Unmarshal(raw, &ids); err != nil {
				return nil, nil, err
			}
		}
		found := false
		for _, previous := range ids {
			found = found || previous == id
		}
		if !found {
			ids = append(ids, id)
		}
		if _, err := protocol.SynopsisReadTable(ids); err != nil {
			return nil, nil, err
		}
		fields["synopsis_read"], _ = json.Marshal(ids)
		raw, err := json.Marshal(fields)
		receipt, _ := json.Marshal(id)
		return raw, receipt, err
	})
	if err != nil {
		return nil, err
	}
	saved.WireID = w.role.WireID
	w.role = saved
	return synopsisRestore(saved.State)
}

func cinematicSkip(store *storage.Store, w *worldSession, p []byte) error {
	if w == nil || w.role.ID == 0 {
		return fmt.Errorf("cinematic requires character")
	}
	id, err := protocol.DecodeCinematicSkip(p)
	if err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	saved, _, err := store.CommitCharacterEvent(ctx, w.role.AccountID, w.role.ID, w.role.ConfigVersion, fmt.Sprintf("cinematic-skip:%d", id), "cinematic-skip-v1", func(current storage.Character) (json.RawMessage, json.RawMessage, error) {
		var fields map[string]json.RawMessage
		if e := json.Unmarshal(current.State, &fields); e != nil {
			return nil, nil, e
		}
		var ids []uint16
		if value := fields["cinematic_skipped"]; value != nil {
			if e := json.Unmarshal(value, &ids); e != nil {
				return nil, nil, e
			}
		}
		found := false
		for _, v := range ids {
			found = found || v == id
		}
		if !found {
			ids = append(ids, id)
		}
		if _, e := protocol.CinematicSkippedScenes(ids); e != nil {
			return nil, nil, e
		}
		fields["cinematic_skipped"], _ = json.Marshal(ids)
		raw, e := json.Marshal(fields)
		receipt, _ := json.Marshal(id)
		return raw, receipt, e
	})
	if err == nil {
		saved.WireID = w.role.WireID
		w.role = saved
	}
	return err
}

func saveStoryDigest(s *storage.Store, w *worldSession, p []byte) error {
	if s == nil || w == nil || w.role.ID == 0 || len(p) != 0 {
		return fmt.Errorf("剧情回顾记录需要已选角色和空正文")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	saved, _, err := s.AdvanceStoryDigest(ctx, w.role.AccountID, w.role.ID, uint32(w.level))
	if err == nil {
		saved.WireID = w.role.WireID
		w.role = saved
	}
	return err
}

func advanceStoryDigest(current json.RawMessage, level uint32) (json.RawMessage, bool, error) {
	var fields map[string]json.RawMessage
	if e := json.Unmarshal(current, &fields); e != nil {
		return nil, false, e
	}
	var cur uint32
	if value := fields["story_digest_level"]; value != nil {
		if e := json.Unmarshal(value, &cur); e != nil {
			return nil, false, e
		}
	}
	if level <= cur {
		// 只向前推进：低于/等于存档值时不写，防止读旧档/回档把进度往回拉。
		return nil, false, nil
	}
	b, _ := json.Marshal(level)
	fields["story_digest_level"] = b
	raw, e := json.Marshal(fields)
	return raw, true, e
}
