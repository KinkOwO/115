package main

import (
	"context"
	"crypto/rand"
	"dfolan/internal/catalog"
	"dfolan/internal/character"
	"dfolan/internal/database"
	"dfolan/internal/dungeon"
	"dfolan/internal/game/protocol"
	"dfolan/internal/inventory"
	"dfolan/internal/legion"
	"dfolan/internal/loot"
	"dfolan/internal/workflow"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"time"
)

// monsterCreateTriggerEnabled 让进图包带上 [monster create trigger] 的真值
// （怪物记录里 Rank 之后那一格，原本恒为 0）。该字段语义尚未确认，
// 所以由环境变量控制：DFO_MONSTER_CREATE_TRIGGER=1 时编码真值，
// 否则编 0，输出与原先完全一致。
func monsterCreateTriggerEnabled() bool {
	return os.Getenv("DFO_MONSTER_CREATE_TRIGGER") == "1"
}

func randomSeed() (uint32, error) {
	var seed uint32
	e := binary.Read(rand.Reader, binary.LittleEndian, &seed)
	return seed, e
}

func (w *worldSession) dungeonGate(p []byte) ([]outboundPacket, error) {
	if w == nil || w.role.ID == 0 {
		return nil, fmt.Errorf("dungeon gate without selected character")
	}
	requested, e := protocol.DecodeDungeonGate(p)
	if e != nil {
		return nil, e
	}
	if w.channelType == 73 || requested == blackPurgatorySquadDungeon {
		if err := w.validateBlackPurgatoryDungeon(requested); err != nil {
			return nil, err
		}
		return []outboundPacket{
			{"黑鸦选图许可", 1, 15, []byte{1}},
			{"黑鸦选图状态", 0, 27, protocol.EnterDungeonSelection()},
		}, nil
	}
	// The town gate sends zero. The client's own tutorial sender (146cce650)
	// supplies a source dungeon ID instead; accept that only when it is this
	// character's own starting route and the route is still owed.
	if requested != 0 {
		if w.bleedingMineStart != nil {
			if err := w.validateBleedingMineDungeon(requested); err != nil {
				return nil, err
			}
			return []outboundPacket{
				{"赤红铁矿选图许可", 1, 15, []byte{1}},
				{"赤红铁矿选图状态", 0, 27, protocol.EnterDungeonSelection()},
			}, nil
		}
		if scene, ok := w.townArrivalScenes[requested]; ok {
			if w.state.Position.Town != scene.Town || w.state.Position.Area != scene.Area {
				return nil, fmt.Errorf("town arrival scene %d requires town area %d/%d", requested, scene.Town, scene.Area)
			}
			if err := w.service.ValidateRestoredPosition(w.level, w.odyssey, w.state.Position); err != nil {
				return nil, err
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			accepted, err := w.acceptedQuestIDs(ctx)
			cancel()
			if err != nil {
				return nil, err
			}
			if scene.QuestID > 65535 || !accepted[uint16(scene.QuestID)] {
				return nil, fmt.Errorf("town arrival scene %d requires accepted source quest %d", requested, scene.QuestID)
			}
			return []outboundPacket{
				{"town_arrival_scene_gate_ack", 1, 15, []byte{1}},
				{"town_arrival_scene_selection_sent", 0, 27, protocol.EnterDungeonSelection()},
			}, nil
		}
		if w.dungeons != nil && dungeon.IsTrainingRoom(*w.dungeons, requested) {
			return []outboundPacket{
				{"training_room_gate_ack", 1, 15, []byte{1}},
				{"dungeon_selection_sent", 0, 27, protocol.EnterDungeonSelection()},
			}, nil
		}
		if w.boostup != nil && w.state.Position.Town == w.boostup.Town {
			// 训练城镇内的副本白名单：只放行源里当前职业/关卡的引导房，其余一律拒绝。
			if e = w.authorizeBoostDungeon(requested); e != nil {
				return nil, e
			}
			return []outboundPacket{
				{"boost_guide_gate_ack", 1, 15, []byte{1}},
				{"boost_guide_selection", 0, 27, boostGuideSelectionPayload()},
			}, nil
		}
		if e = w.authorizeTutorial(requested); e != nil {
			return nil, e
		}
		return []outboundPacket{
			{"tutorial_gate_ack", 1, 15, []byte{1}},
			{"dungeon_selection_sent", 0, 27, protocol.EnterDungeonSelection()},
		}, nil
	}
	a, ok := w.service.Catalog.Areas[catalog.AreaKey(w.state.Position.Town, w.state.Position.Area)]
	if !ok || a.Kind != "[dungeon gate]" {
		return nil, fmt.Errorf("source area is not a PVF dungeon gate")
	}
	// The gate belongs to the area the character already stands in.
	if e = w.service.ValidateRestoredPosition(w.level, w.odyssey, w.state.Position); e != nil {
		return nil, e
	}
	return []outboundPacket{
		{"dungeon_gate_ack", 1, 15, []byte{1}},
		{"dungeon_selection_sent", 0, 27, protocol.EnterDungeonSelection()},
	}, nil
}

func (w *worldSession) isTownArrivalOriginSync(id uint16, p []byte) bool {
	if w == nil || w.pendingTownArrival == nil || id != 36 {
		return false
	}
	r, err := protocol.DecodeAreaChangeRequest(p)
	if err != nil {
		return false
	}
	pos := w.state.Position
	return r.Town == pos.Town && r.Area == pos.Area && r.X == pos.X && r.Y == pos.Y &&
		r.PreviousTown == pos.Town && uint32(r.PreviousArea) == pos.Area && r.Flag == 0 && r.TailFlags == [2]byte{}
}

func towerPolicy(t *catalog.TowerRuntime) database.TowerPolicy {
	return database.TowerPolicy{Key: t.Key, TopFloor: t.TopFloor, DailyEntries: t.DailyEntries, ResetHourUTC: t.ResetHourUTC}
}

func (w *worldSession) towerProgress(ctx context.Context, tower *catalog.TowerRuntime) (database.TowerProgress, []uint32, error) {
	var empty database.TowerProgress
	if w == nil || tower == nil || w.dungeons == nil || w.characters == nil || w.store == nil {
		return empty, nil, fmt.Errorf("tower progress unavailable")
	}
	floors, err := w.dungeons.TowerFloors(tower.Key, tower.TopFloor)
	if err != nil {
		return empty, floors, err
	}
	var legacyFloor uint16
	if tower.Key == "grief" {
		var griefFloors [101]uint32
		copy(griefFloors[:], floors)
		legacy, err := w.store.TowerGriefProgress(ctx, w.account, griefFloors)
		if err != nil {
			return empty, floors, err
		}
		legacyFloor = legacy.HighestCleared
	}
	progress, err := w.store.ReadTowerProgress(ctx, w.account, towerPolicy(tower), legacyFloor)
	return progress, floors, err
}

func (w *worldSession) selectDungeon(p []byte) (*dungeon.Session, []outboundPacket, error) {
	if w == nil || w.dungeons == nil || w.role.ID == 0 {
		return nil, nil, fmt.Errorf("dungeon catalog or character unavailable")
	}
	if w.activeDungeon != nil {
		return nil, nil, fmt.Errorf("dungeon entry already active")
	}
	r, e := protocol.DecodeDungeonSelection(p)
	if e != nil {
		return nil, nil, e
	}
	if w.channelType == 73 || r.ID == blackPurgatorySquadDungeon {
		if !w.selectingDungeon || w.approvedDungeonGate != r.ID || r.Difficulty != 2 {
			return nil, nil, fmt.Errorf("黑鸦小队缺少本次选图许可或源难度不匹配")
		}
		if err := w.validateBlackPurgatoryDungeon(r.ID); err != nil {
			return nil, nil, err
		}
		return w.prepareDungeonEntry(r)
	}
	if w.bleedingMineStart != nil {
		if !w.selectingDungeon || w.approvedDungeonGate != r.ID {
			return nil, nil, fmt.Errorf("赤红铁矿缺少本次开战的选图许可")
		}
		if err := w.validateBleedingMineDungeon(r.ID); err != nil {
			return nil, nil, err
		}
		return w.prepareDungeonEntry(r)
	}
	if scene, ok := w.townArrivalScenes[r.ID]; ok {
		// A quest's arrival trigger is a town event. A rejected CMD15 must not
		// become a private dungeon session through the following CMD16.
		if r.Quest != scene.QuestID || w.state.Position.Town != scene.Town || w.state.Position.Area != scene.Area || !w.selectingDungeon || w.approvedDungeonGate != r.ID {
			return nil, nil, fmt.Errorf("town arrival scene %d has no approved matching gate for quest %d at %d/%d", r.ID, r.Quest, w.state.Position.Town, w.state.Position.Area)
		}
	}
	if d, ok := w.dungeons.Dungeons[r.ID]; ok && d.Odyssey {
		if !character.OdysseyRole(w.role) {
			return nil, nil, fmt.Errorf("Odyssey dungeon requires an Odyssey character")
		}
	}
	// 训练城镇里的选图只走活动引导房：普通 tutorialDungeons 起始路线在
	// 活动城镇不适用，也不能凭 ID 撞上就开局。
	if w.boostup != nil && w.state.Position.Town == w.boostup.Town {
		if !w.selectingDungeon || w.approvedDungeonGate != r.ID {
			return nil, nil, fmt.Errorf("boost guide lacks this selection approval")
		}
		if e = w.authorizeBoostDungeon(r.ID); e != nil {
			return nil, nil, e
		}
		return w.prepareDungeonEntry(r)
	}
	// A starting route names its own dungeon and has no town gate to stand
	// at, so it is resolved before the ordinary gate check.
	if w.tutorialDungeons != nil {
		if _, ok := w.tutorialDungeons.Dungeons[r.ID]; ok {
			return w.selectTutorial(r.ID)
		}
	}
	trainingRoom := dungeon.IsTrainingRoom(*w.dungeons, r.ID)
	if _, townArrival := w.townArrivalScenes[r.ID]; !trainingRoom && !townArrival {
		if _, e := w.dungeonGate(make([]byte, 8)); e != nil {
			return nil, nil, e
		}
	}
	return w.prepareDungeonEntry(r)
}

// 普通选图与已完成准入校验的特殊副本共用场景准备，不重复触发城镇门校验。
func (w *worldSession) prepareDungeonEntry(r protocol.DungeonSelection) (*dungeon.Session, []outboundPacket, error) {
	if w.soloPartyReady && r.Party == 1 {
		// This connection owns the single-member bootstrap party. The dungeon
		// domain remains solo; never normalize arbitrary party IDs.
		r.Party = 65535
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if definition, ok := w.dungeons.Dungeons[r.ID]; ok && definition.Tower != nil {
		tower := definition.Tower
		policy := towerPolicy(tower)
		progress, floors, err := w.towerProgress(ctx, tower)
		if err != nil {
			return nil, nil, err
		}
		if progress.HighestCleared >= policy.TopFloor {
			return nil, nil, fmt.Errorf("%s tower is fully cleared", policy.Key)
		}
		next := progress.HighestCleared + 1
		// The selection UI may still submit its static first-floor ID. The
		// verified PVF layer table supplies the actual next dungeon ID.
		if tower.Floor == 1 && next != 1 {
			r.ID = floors[next]
		} else if tower.Floor != next {
			return nil, nil, fmt.Errorf("%s tower floor %d is locked", policy.Key, tower.Floor)
		}
	}
	var s *dungeon.Session
	var e error
	if dungeon.IsTrainingRoom(*w.dungeons, r.ID) {
		s, e = dungeon.SelectTrainingRoom(*w.dungeons, r, w.level)
	} else {
		var accepted map[uint16]bool
		accepted, e = w.acceptedQuestIDs(ctx)
		if e == nil {
			// 引导副本在源里是 `[tutorial dungeon]`，普通 Select 一律拒绝教程房（实机
			// 2026-10-04 14:43 第二关 CMD16 `100004558` 被 unsupported dungeon option
			// 挡下）。判据与 authorizeBoostDungeon 同源，不是第二套规则。
			if w.boostGuideSelection(r.ID) {
				s, e = dungeon.SelectGuide(*w.dungeons, r, w.level, accepted)
			} else {
				s, e = dungeon.Select(*w.dungeons, r, w.level, accepted)
			}
		}
	}
	if e != nil {
		return nil, nil, e
	}
	noteMazeEntry(s)
	if w.fatigue != nil && !s.Definition.NoFatigue && w.fatigue.EnterCostFor(s.Definition.ID) > 0 {
		fp, err := w.fatigue.State(ctx, w.account, w.role.ID, time.Now())
		if err != nil {
			return nil, nil, err
		}
		if fp.Used >= fp.Limit {
			return nil, nil, database.ErrFatigueExhausted
		}
	}
	plan, e := w.dungeonEntryPlan(context.Background(), "dungeon_select_ack", 16, r, s)
	if e != nil {
		return nil, nil, e
	}
	if tower := s.Definition.Tower; tower != nil {
		if _, e = w.store.ReserveTowerEntry(ctx, w.account, towerPolicy(tower), tower.Floor, time.Now()); e != nil {
			return nil, nil, e
		}
	}
	return s, plan, nil
}

// dungeonEntryPlan is the frame sequence the client needs to load a dungeon it
// has just asked for: the acknowledgement for that request, the actor display
// state, the solo party bootstrap, NOTI 28 (dungeon info) and NOTI 29 (start
// map). Both the town selection (CMD 16) and the post-clear "next story
// dungeon" gate (CMD 2062) replay it unchanged - only the ack id differs,
// because the client loads a whole new dungeon either way.
func (w *worldSession) dungeonEntryPlanImpl(ctx context.Context, ackName string, ackID uint16, sel protocol.DungeonSelection, s *dungeon.Session, channelCtx *[2]byte) ([]outboundPacket, error) {
	if s.HellParty != nil {
		log.Printf("Hell Party selected: dungeon=%d map=%d mode=%s(%d) S4 compatibility rows=%+v actor groups=%+v", s.Definition.ID, s.HellParty.Map, s.HellParty.Key, s.HellParty.Mode, s.HellParty.Rows, s.HellParty.Actors)
	}
	var seed uint32
	if e := binary.Read(rand.Reader, binary.LittleEndian, &seed); e != nil {
		return nil, e
	}
	if s.Tournament != nil {
		seed = s.Tournament.Seed
	}
	start, e := protocol.StartMap(protocol.StartMapState{Position: s.Maze.Start, Seed: seed, Map: s.Room.Map, Monsters: s.Monsters, HellPartyMode: s.HellPartyMode(), EncodeCreateTrigger: monsterCreateTriggerEnabled()})
	if e != nil {
		return nil, e
	}
	plan := []outboundPacket{{ackName, 1, ackID, []byte{1}}}
	if w.characters != nil {
		channel := [2]byte{}
		if channelCtx != nil {
			channel = *channelCtx
		} else if w.channelType == 73 && w.blackPurgatory.created {
			channel = w.characters.ChannelContext
		}
		visual, err := w.characters.EntryBasicProbe(w.role, channel)
		if err == nil {
			plan = append(plan, outboundPacket{"dungeon_actor_appearance_sent", 0, 2, visual})
		}
		addition, err := w.characters.EntryAddition(w.role)
		if err == nil {
			plan = append(plan, outboundPacket{"dungeon_actor_addition_sent", 0, 2, addition})
		}
		wornUpdate, err := inventory.WornSpaceUpdate(w.role.State)
		if err == nil && len(wornUpdate) > 0 {
			plan = append(plan, outboundPacket{"dungeon_worn_visuals_sent", 0, 14, wornUpdate})
		}
		if inventory.HasEquippedCreature(w.role.State) {
			clPayload, err := inventory.CreatureListPayload(w.role.State)
			if err == nil {
				plan = append(plan, outboundPacket{"dungeon_creature_list_sent", 0, 105, clPayload})
				growth, err := inventory.CreatureGrowthPayload(w.role.State)
				if err == nil {
					plan = append(plan, outboundPacket{"dungeon_creature_growth_sent", 0, 102, growth})
				}
			}
		}
	}
	// 黑鸦已在大厅建立原生小队，入图不能用普通队伍通知覆盖模式和开场状态。
	if w.soloPartyBootstrap && !(w.channelType == 73 && w.blackPurgatory.created) {
		party, e := protocol.SoloPartyInfo(w.role.WireID)
		if e != nil {
			return nil, e
		}
		plan = append(plan, outboundPacket{"solo_party_initialized", 0, 9, party})
	}
	// Full worn refresh can recreate Clone objects without their inherited
	// cover. Refresh first, then rebuild Clone and restore only non-avatar
	// rows (including oath slots 36..47 cleared by mode 1). Apply the oath
	// selection last, before NOTI29. Loading must not repeat reconstruction
	// for this path.
	if direct, directErr := w.oathDirectEntryPackets(ctx); directErr != nil {
		return nil, directErr
	} else if len(direct) > 0 {
		// oathDirectEntryPackets ends with the selection; all earlier packets
		// are worn refreshes and must precede the Clone cover reconstruction.
		plan = append(plan, direct[:len(direct)-1]...)
		reset, full, enabled, err := w.characters.CloneReattachPackets(w.role)
		if err != nil {
			return nil, err
		}
		if enabled {
			sources, sourceErr := cloneAvatarSourcePackets(w.role.State)
			if sourceErr != nil {
				return nil, sourceErr
			}
			plan = append(plan, sources...)
			restore, err := inventory.NonAvatarWornSpaceUpdate(w.role.State)
			if err != nil {
				return nil, err
			}
			plan = append(plan,
				outboundPacket{"dungeon_clone_detached_pre_direct", 0, 2, reset},
				outboundPacket{"dungeon_clone_reattached_pre_direct", 0, 2, full},
			)
			if len(restore) > 0 {
				plan = append(plan, outboundPacket{"dungeon_nonavatar_worn_restored_pre_direct", 0, 14, restore})
			}
		}
		plan = append(plan, direct[len(direct)-1])
	}
	if rows := s.HellPartyAPCs(); len(rows) > 0 {
		body, err := protocol.HellPartyMonsterInfo(rows)
		if err != nil {
			return nil, err
		}
		plan = append(plan, outboundPacket{"hell_party_apcs_preloaded", 0, 666, body})
	}
	// 苏醒之森用官服 48B N28 形状 + N1584 STACKABLE_DUNGEON_LIMIT（官方
	// 21:42:18.601 实发、首字段 = 8 = 每关消耗品上限；伊斯 replay 同款——
	// 伊斯副本能用药正是因为发了它。没有这一帧客户端把消耗品全部本地禁用，
	// 0953 会话实证 N28 48B 单独无效，限制载体是本包）。
	dungeonInfo := protocol.DungeonInfo(protocol.DungeonInfoState{ID: sel.ID, Difficulty: sel.Difficulty, Maze: s.Maze.Index, Boss: s.Maze.Boss, Hell: s.HellPosition})
	var stackableLimit []outboundPacket
	// N1584 STACKABLE_DUNGEON_LIMIT：副本消耗品许可（@0 = 每关上限 8）。
	// 森林与维纳斯军团本都需要：没有这一帧客户端把副本消耗品全部本地禁用
	//（两个团本的会话均零 CMD44 实证；伊斯 replay 同款、副本内可用药）。
	if w.forest != nil && legion.IsForestStageDungeonAny(sel.ID) {
		dungeonInfo = protocol.ForestDungeonInfo(sel.ID, s.Maze.Index, s.Maze.Boss, seed)
		stackableLimit = []outboundPacket{{"forest_stackable_dungeon_limit", 0, 1584, protocol.StackableDungeonLimit(8, seed)}}
	} else if w.venus != nil && legion.IsVenusStageDungeon(sel.ID) {
		stackableLimit = []outboundPacket{{"venus_stackable_dungeon_limit", 0, 1584, protocol.StackableDungeonLimit(8, seed)}}
	}
	plan = append(plan, []outboundPacket{
		{"dungeon_info_sent", 0, 28, dungeonInfo},
		{"dungeon_start_map_sent", 0, 29, start},
	}...)
	plan = append(plan, stackableLimit...)
	if s.Tournament != nil {
		info, err := protocol.TournamentInfo(s.Tournament.Opening)
		if err != nil {
			return nil, err
		}
		mapInfo, err := protocol.TournamentMapInfo(s.Maze.Start, seed, s.Room.Map)
		if err != nil {
			return nil, err
		}
		plan = append(plan,
			outboundPacket{"tournament_info_sent", 0, 372, info},
			outboundPacket{"tournament_map_info_sent", 0, 373, mapInfo},
		)
	}
	return plan, nil
}

// dungeonEntryPlan 是 dungeonEntryPlanImpl 的普通进图入口（客户端自己发起：
// 点门 → C16，身份上下文客户端本地就有，channelCtx 传 nil）。
func (w *worldSession) dungeonEntryPlan(ctx context.Context, ackName string, ackID uint16, sel protocol.DungeonSelection, s *dungeon.Session) ([]outboundPacket, error) {
	return w.dungeonEntryPlanImpl(ctx, ackName, ackID, sel, s, nil)
}

// directMoveDungeon handles CMD 2062 (ENUM_CMDPACKET_DUNGEON_DIRECT_MOVE): the
// "next story dungeon" gate the client offers beside "return to town" after a
// clear. The finished run is replaced by the requested one, with the same
// source gate keeping as the town selection (level, difficulty, maze quest)
// and the same entry sequence, because the client loads a whole new dungeon
// from this request. The town-only checks of CMD 16 (standing on a PVF
// [dungeon gate] area) do not apply inside a run.
// acceptedQuestIDs is the prerequisite set the dungeon gate check consumes.
// The client's own wording is "accepted **or** completed prerequisite quests",
// so completed ones count too; only accepted would lock out a dungeon whose
// quest the character already finished.
func (w *worldSession) acceptedQuestIDs(ctx context.Context) (map[uint16]bool, error) {
	quests, e := w.store.Quests(ctx, w.account, w.role.ID)
	if e != nil {
		return nil, e
	}
	accepted := map[uint16]bool{}
	for _, q := range quests {
		if (q.Status == "accepted" || q.Status == "completed") && q.ConfigVersion == w.dungeons.Source.SaveIdentity() {
			accepted[q.ID] = true
		}
	}
	return accepted, nil
}

func (w *worldSession) directMoveDungeon(p []byte) (*dungeon.Session, []outboundPacket, error) {
	if w == nil || w.dungeons == nil || w.role.ID == 0 {
		return nil, nil, fmt.Errorf("dungeon catalog or character unavailable")
	}
	// 苏醒之森直进：音符记录类型 0x04 的关卡，客户端确认音符后不走 CMD2045
	// 而发 CMD2062 直进下一关（官服 21:44:34.387、私服 21:06 会话实证）。
	// 此时上一关会话已在 forestResult（CMD46）收尾、activeDungeon 为空，因此
	// 必须在通用 activeDungeon 门控与解码之前接管（目录校验在分支内部做）。
	// 连战模式的 2062 @13 可能是 0（客户端本地记录表没有该阶段的副本号——
	// 0231 会话实证），因此分支条件放宽为「存在 forest run 即接手」，阶段号
	// 由 enterForestStageDirectMove 按 run.cleared 推断。
	if w.forest != nil && (legion.IsForestStageDungeonInPacket(p) || legion.IsForestDirectMoveCandidate(p)) {
		r, e := protocol.DecodeDungeonDirectMove(p)
		if e != nil {
			return nil, nil, e
		}
		return w.enterForestStageDirectMove(r)
	}
	if w.activeDungeon == nil {
		return nil, nil, fmt.Errorf("direct move without an active dungeon")
	}
	r, e := protocol.DecodeDungeonDirectMove(p)
	if e != nil {
		return nil, nil, e
	}
	if w.bleedingMineStart != nil {
		return w.advanceBleedingMine(r)
	}
	// 维纳斯阶段副本的直进 = 清怪后的原生转阶段（客户端按 N2655 推进后的
	// 阶段记录解析目标副本，2026-10-04 14:41 实机）。必须在这里接管，否则
	// 普通路径会建出无怪空房、客户端秒清后再转，形成无限进图循环。
	if legion.IsVenusStageDungeon(r.ID) {
		return w.enterVenusStageDirectMove(r)
	}
	d, ok := w.dungeons.Dungeons[r.ID]
	if !ok {
		return nil, nil, fmt.Errorf("direct move target absent from imported source")
	}
	if d.Odyssey && !character.OdysseyRole(w.role) {
		return nil, nil, fmt.Errorf("Odyssey dungeon requires an Odyssey character")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if w.fatigue != nil && !d.NoFatigue && w.fatigue.EnterCostFor(d.ID) > 0 {
		fp, err := w.fatigue.State(ctx, w.account, w.role.ID, time.Now())
		if err != nil {
			return nil, nil, err
		}
		if fp.Used >= fp.Limit {
			return nil, nil, database.ErrFatigueExhausted
		}
	}
	// The direct-move body carries the dungeon id and difficulty only, so the
	// remaining selection fields take the values CMD 16 uses for a solo run.
	sel := protocol.DungeonSelection{ID: r.ID, Difficulty: r.Difficulty, Party: 65535}
	var s *dungeon.Session
	if dungeon.IsTrainingRoom(*w.dungeons, r.ID) {
		s, e = dungeon.SelectTrainingRoom(*w.dungeons, sel, w.level)
	} else {
		var accepted map[uint16]bool
		accepted, e = w.acceptedQuestIDs(ctx)
		if e == nil {
			s, e = dungeon.Select(*w.dungeons, sel, w.level, accepted)
		}
	}
	if e != nil {
		return nil, nil, e
	}
	noteMazeEntry(s)
	plan, e := w.directMoveEntryPlan(sel, s)
	if e != nil {
		return nil, nil, e
	}
	// 客户端在「清关 → 点下一个剧情关卡门」后不再接受普通房间门（实机 A/B：它收到的
	// 进图帧与城镇选图逐字节一致，却整个下一关都不发 MOVE_MAP，取证见
	// docs/protocol/next49-odyssey-direct-move.md）。清关后客户端另有一个「选择其他
	// 地下城」入口，走的是 gate_ack(15) + selection_sent(27) 这条 UI 层帧；先进这个
	// 界面再下发进图帧，避免用"回城帧"造成的场景切换与进图撞车（实测那会让客户端
	// 黑屏退出）。
	return s, append(dungeonSelectionHead(), plan...), nil
}

// dungeonSelectionHead is the client's dungeon-select UI layer: the gate
// acknowledgement and NOTI 27. Whenever an entry sequence is sent to a client
// that is not already standing in the town selection flow - the post-clear
// "next story dungeon" gate and the settlement panel's "again" button - it has
// to be preceded by this pair, or the entry frames land on a scene the client
// has already torn down and it exits (0xC0000005).
func dungeonSelectionHead() []outboundPacket {
	return []outboundPacket{
		{"dungeon_gate_ack", 1, 15, []byte{1}},
		{"dungeon_selection_sent", 0, 27, protocol.EnterDungeonSelection()},
	}
}

// directMoveEntryPlan is the CMD 2062 form of dungeonEntryPlan: the client
// starts this run from its own direct-move request, and the town selection
// sequence is what its dungeon context expects.
//
// Live A/B in one session (2026-09-21, dungeon 100004950 "安徒恩讨伐战"):
//
//	15:38:03 entered via CMD 2062 and the server answered
//	         dungeon_direct_move_ack(2062) + dungeon_select_ack(16):
//	         the first room advanced, but after the layer change to 100016165
//	         the client stopped sending room requests altogether and the run
//	         stalled there.
//	15:41:09 entered via the town gate (CMD 15/16), server answered
//	         dungeon_select_ack(16) only: first room, the same layer map and
//	         all ten rooms up to the boss room 100016175 advanced normally.
//
// The two entry sequences differ by nothing but that 2062 acknowledgement, so
// it is dropped here: the direct move replays the town selection entry exactly.
func (w *worldSession) directMoveEntryPlan(sel protocol.DungeonSelection, s *dungeon.Session) ([]outboundPacket, error) {
	return w.dungeonEntryPlan(context.Background(), "dungeon_select_ack", 16, sel, s)
}

func (w *worldSession) finishDungeonLoading(p []byte) ([]outboundPacket, error) {
	if w == nil || w.activeDungeon == nil {
		return nil, fmt.Errorf("loading without dungeon session")
	}
	// Current solo loading request is a zeroed 16-byte record. Refuse other
	// options until their native send fields are supported.
	if len(p) != 16 {
		return nil, fmt.Errorf("unexpected loading record length")
	}
	for _, b := range p {
		if b != 0 {
			return nil, fmt.Errorf("unsupported loading option")
		}
	}
	// 誓约进图直发是否命中：它决定下面三处（穿戴快照 13 / 视觉与随机属性 14 / Clone 重建）
	// 要不要**重复**发送。直入时这些内容都已经在 NOTI29 之前发过了，再发一次会让原生
	// 把穿戴效果应用两次（施工图描述的「Buff 两次」来源）。查一次，三处共用。
	directEntry, directErr := w.oathDirectEntryActive(context.Background())
	if directErr != nil {
		return nil, directErr
	}
	state, e := protocol.UserState(w.role.WireID, protocol.UserStateDungeon)
	if e != nil {
		return nil, e
	}
	// 征兆存档必须先读出来：它同时决定 noti 2836 的队伍状态（omen_info.go）与
	// noti 2838 的档位（oath_info.go —— 隐藏 BOSS 现在由「满档结算」驱动）。
	if e := w.loadOmenRunState(w.oathProgressDungeon()); e != nil {
		return nil, e
	}
	// 官服巴卡尔军团段（20261002 抓包 21:42:19）：CMD37 ack 之后、N30 之前
	// 下发 N1474 阶段倒计时（伊斯官服 timer_sync 回放同序）。非维纳斯零开销。
	plan := []outboundPacket{{"dungeon_loading_ack", 1, 37, []byte{1}}, {"dungeon_actor_state", 0, 3, state}}
	plan = append(plan, w.venusStageTimer(time.Now())...)
	// 苏醒之森关卡倒计时：同款挂点（官服 21:42:19.431 N1474，60 分钟/关）。
	plan = append(plan, w.forestStageTimer(time.Now())...)
	plan = append(plan, outboundPacket{"dungeon_loading_complete", 0, 30, protocol.DungeonLoaded()})
	// 常驻状态：把两个档位在客户端读 getter 之前下发（见 oath_info.go）。
	grades, e := w.oathInfoPackets()
	if e != nil {
		return nil, e
	}
	plan = append(plan, grades...)
	// 征兆队伍状态（noti 2836）。客户端进 EOO 副本时自己已经把两个征兆窗开好，
	// 这里只负责把每个座位的状态填进去。见 omen_info.go。
	omen, e := w.omenInfoPackets()
	if e != nil {
		return nil, e
	}
	plan = append(plan, omen...)
	// 诊断注入器：把候选通知塞在副本加载应答里，天平开场读 getter 之前就到位。
	plan = append(plan, w.oathInjectNext()...)
	if w.progression != nil {
		p, err := character.ExperiencePayload(w.role)
		if err != nil {
			return nil, err
		}
		plan = append(plan, outboundPacket{"dungeon_experience_restored", 0, 37, p})
	}
	if w.fatigue != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		blackPackets, err := w.blackPurgatoryLoaded(ctx)
		if err != nil {
			return nil, err
		}
		plan = append(plan, blackPackets...)
		d := w.activeDungeon
		fp, _, e := w.fatigue.EnterRoomForDungeon(ctx, w.account, w.role.ID, d.RunID, d.Room.Map, d.Definition.ID, d.Definition.NoFatigue, time.Now())
		if e != nil {
			// 「限制」必须在进入之前生效，绝不能发生在副本里面：客户端已经进本、
			// 正在等这条加载应答，回一个它不认识的拒绝形状就等于让它卡在加载界面
			//（2026-10-01 实测过一次，见分析文档 §九）。这里把加载应答发完，
			// 再立刻把角色完整送回城镇。
			log.Printf("dungeon %d 进本记费失败（%v）：已放行加载并立即退回城镇，避免卡死", d.Definition.ID, e)
			w.activeDungeon = nil
			leave, le := w.leaveDungeon()
			if le != nil {
				return nil, le
			}
			return append(plan, leave...), nil
		}
		p, e := protocol.Fatigue(fp.Used, fp.Limit, fp.UsedMax)
		if e != nil {
			return nil, e
		}
		plan = append(plan, outboundPacket{"dungeon_fatigue_updated", 0, 36, p})
	}
	cloneReattached := false
	if w.characters != nil {
		// Dungeon actor reconstruction does not carry oath slot 47 in the
		// mode-1 detail record. Restore the authoritative worn container before
		// applying slot updates and the oath selection, as town entry does.
		// 誓约进图直发命中时，这三项已在 NOTI29 之前发过 ⇒ 此处不再重复
		// （否则穿戴效果会被应用两次 —— 正是施工图描述的"Buff 两次"来源）。
		if !directEntry {
			wornSnapshot, err := inventory.WornPayload(w.role.State)
			if err != nil {
				return nil, err
			}
			plan = append(plan, outboundPacket{"dungeon_worn_equipment_restored", 0, 13, wornSnapshot})
			wornUpdate, err := inventory.WornSpaceUpdate(w.role.State)
			if err == nil && len(wornUpdate) > 0 {
				plan = append(plan, outboundPacket{"dungeon_worn_visuals_restored", 0, 14, wornUpdate})
			}
		}
		reset, full, enabled, err := w.characters.CloneReattachPackets(w.role)
		if err != nil {
			return nil, err
		}
		if enabled && !directEntry {
			sources, sourceErr := cloneAvatarSourcePackets(w.role.State)
			if sourceErr != nil {
				return nil, sourceErr
			}
			plan = append(plan, sources...)
			cloneReattached = true
			restore, restoreErr := inventory.NonAvatarWornSpaceUpdate(w.role.State)
			if restoreErr != nil {
				return nil, restoreErr
			}
			plan = append(plan,
				outboundPacket{"dungeon_clone_detached", 0, 2, reset},
				outboundPacket{"dungeon_clone_reattached", 0, 2, full},
			)
			if len(restore) > 0 {
				plan = append(plan, outboundPacket{"dungeon_nonavatar_worn_restored", 0, 14, restore})
			}
		}
		if inventory.HasEquippedCreature(w.role.State) {
			clPayload, err := inventory.CreatureListPayload(w.role.State)
			if err == nil {
				plan = append(plan, outboundPacket{"dungeon_creature_list_restored", 0, 105, clPayload})
				growth, err := inventory.CreatureGrowthPayload(w.role.State)
				if err == nil {
					plan = append(plan, outboundPacket{"dungeon_creature_growth_restored", 0, 102, growth})
				}
			}
		}
		// The damage font the player applied in town is state the rebuilt actor
		// never asks the warehouse for, so the owned page and the selection go
		// back here the way the worn visuals do.
		plan = append(plan, w.damageFontRestore()...)
	}
	if w.characters != nil && w.store != nil {
		// Direct entry already restored the selection before NOTI29. The
		// fallback must apply it after any Clone reconstruction cleared slot 47.
		if !directEntry || cloneReattached {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			selection, err := w.dungeonOathSelectionPacket(ctx)
			if err != nil {
				return nil, err
			}
			plan = append(plan, selection)
		}
	}
	if w.activeDungeon.Definition.ID == 100003126 {
		// Elvenmere 初始化层数：根据进图选取的 Zone（Extra）设置当前层与最高已通关层。
		floor := byte(w.activeDungeon.Extra)
		if floor == 0 {
			floor = 1
		}
		var maxCleared byte
		if floor > 1 {
			maxCleared = floor - 1
		}
		plan = append(plan, outboundPacket{"elvenmere_info_sent", 0, 2193, protocol.ElvenmereInfo(floor, maxCleared, w.activeDungeon.WeeklyRewards, w.activeDungeon.SeasonRewards)})
	}
	// 房间重建会重置原生场景计时器，每次加载均同步同一个挑战期限。
	plan = append(plan, w.bleedingMineTimer(time.Now())...)
	// 维纳斯首关三只圣物怪是事件怪：不能编进 N29 固定行（venus_1phase.map
	// 无 [monster] 段，客户端按 SourceIndex 找不到源行就不建怪——2026-10-04
	// 13:52 实机），照月湖动态怪先例在真实 C37 加载完成后用 N2194 注册。
	plan = append(plan, w.venusDynamicSpawnPackets()...)
	// 随机属性块（NOTI14 list3）与上面的 13/14 同源：直入时 ID13 的整份穿戴快照
	// （WornPayload = list3 + restore=true）已经把实例行连同 record[60:76] 一起给过，
	// 这里再发一次会让原生临时随机属性管理器**应用两次**。
	// 回退路径（含 Clone 重建后）仍然要发 —— 那时克隆重建把普通装备的行冲掉了。
	if !directEntry {
		plan, e = appendDungeonWornRandomOptions(plan, w)
		if e != nil {
			return nil, e
		}
	}
	return appendBuffEnhancementRestore(plan, w.characters, w.role, "dungeon_buff_enhancement_restored")
}

func (w *worldSession) elvenmereTeleport(p []byte) ([]outboundPacket, error) {
	if w == nil || w.activeDungeon == nil {
		return nil, fmt.Errorf("teleport without active dungeon session")
	}
	if w.activeDungeon.Definition.ID != 100003126 {
		return nil, fmt.Errorf("elvenmere teleport in non-elvenmere dungeon")
	}
	if len(p) < 25 {
		return nil, fmt.Errorf("short elvenmere teleport payload")
	}

	// 刚刚通关的层数
	clearedFloor := byte(w.activeDungeon.Extra)
	if clearedFloor == 0 {
		clearedFloor = 1
	}

	// 传送至下一层
	nextFloor := clearedFloor + 1
	if nextFloor > 100 {
		nextFloor = 100
	}
	w.activeDungeon.Extra = uint16(nextFloor)
	maxCleared := clearedFloor

	plan := []outboundPacket{
		{"elvenmere_teleport_ack", 1, 2015, []byte{1}},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// 1. 发放通关道具奖励（Seed Coin / 叶之金币及赛季奖励）
	// 周常奖励
	if clearedFloor >= 1 && clearedFloor <= 100 && w.activeDungeon.WeeklyRewards[clearedFloor-1] == 0 {
		w.activeDungeon.WeeklyRewards[clearedFloor-1] = 1
		itemTemplate, itemCount := dungeon.ElvenmereFloorWeeklyReward(clearedFloor)
		if itemTemplate != 0 && itemCount > 0 && w.loot != nil {
			awarder := &inventory.Awarder{
				Catalog:   w.loot.Catalog,
				Rules:     w.loot.BagRules,
				Equipment: w.loot.Equipment,
			}
			before, _ := inventory.ReadBag(w.role.State)
			if updated, _, err := awarder.Grant(w.role.State, itemTemplate, itemCount); err == nil {
				w.role.State = updated
				if store := w.store; store != nil {
					key := fmt.Sprintf("elvenmere-weekly:%s:%d", w.activeDungeon.RunID, clearedFloor)
					_, _, _ = store.CommitCharacterEvent(ctx, w.role.AccountID, w.role.ID, w.role.ConfigVersion, key, "elvenmere-reward-v1", func(current database.Character) (json.RawMessage, json.RawMessage, error) {
						proof, _ := json.Marshal(map[string]any{"template": itemTemplate, "amount": itemCount, "floor": clearedFloor})
						return updated, proof, nil
					})
				}
				if b, err := inventory.ReadBag(updated); err == nil {
					if updatePayload, err := protocol.InventoryUpdate(inventory.ChangedItemRows(before, b)); err == nil {
						plan = append(plan, outboundPacket{"elvenmere_inventory_updated", 0, 14, updatePayload})
					}
				}
			}
		}
	}

	// 逢5层检查发放赛季首通奖励
	if clearedFloor%5 == 0 && clearedFloor >= 5 && clearedFloor <= 100 && w.activeDungeon.SeasonRewards[clearedFloor-1] == 0 {
		w.activeDungeon.SeasonRewards[clearedFloor-1] = 1
		sTemplate, sCount := dungeon.ElvenmereFloorSeasonReward(clearedFloor)
		if sTemplate != 0 && sCount > 0 && w.loot != nil {
			awarder := &inventory.Awarder{
				Catalog:   w.loot.Catalog,
				Rules:     w.loot.BagRules,
				Equipment: w.loot.Equipment,
			}
			before, _ := inventory.ReadBag(w.role.State)
			if updated, _, err := awarder.Grant(w.role.State, sTemplate, sCount); err == nil {
				w.role.State = updated
				if store := w.store; store != nil {
					key := fmt.Sprintf("elvenmere-season:%s:%d", w.activeDungeon.RunID, clearedFloor)
					_, _, _ = store.CommitCharacterEvent(ctx, w.role.AccountID, w.role.ID, w.role.ConfigVersion, key, "elvenmere-reward-v1", func(current database.Character) (json.RawMessage, json.RawMessage, error) {
						proof, _ := json.Marshal(map[string]any{"template": sTemplate, "amount": sCount, "floor": clearedFloor})
						return updated, proof, nil
					})
				}
				if b, err := inventory.ReadBag(updated); err == nil {
					if updatePayload, err := protocol.InventoryUpdate(inventory.ChangedItemRows(before, b)); err == nil {
						plan = append(plan, outboundPacket{"elvenmere_inventory_updated", 0, 14, updatePayload})
					}
				}
			}
		}
	}

	// 2. 发放通关经验奖励（Floor Clear EXP）
	expGain := dungeon.ElvenmereFloorClearExp(clearedFloor)
	if expGain > 0 && w.progression != nil {
		previousLevel := w.level
		if updatedRole, _, err := w.progression.ApplyGain(w.role, expGain); err == nil {
			updatedRole.WireID = w.role.WireID
			w.role = updatedRole
			if store := w.store; store != nil {
				key := fmt.Sprintf("elvenmere-exp:%s:%d", w.activeDungeon.RunID, clearedFloor)
				_, _, _ = store.CommitCharacterEvent(ctx, w.role.AccountID, w.role.ID, w.role.ConfigVersion, key, "elvenmere-exp-v1", func(current database.Character) (json.RawMessage, json.RawMessage, error) {
					proof, _ := json.Marshal(map[string]any{"exp": expGain, "floor": clearedFloor})
					return updatedRole.State, proof, nil
				})
			}
			if expPayload, err := character.ExperiencePayload(updatedRole); err == nil {
				w.level = expPayload[0]
				plan = append(plan, outboundPacket{"elvenmere_experience_updated", 0, 37, expPayload})
				if w.level != previousLevel {
					if skills, err := w.automaticSkillRefresh(); err == nil {
						plan = append(plan, skills...)
					}
				}
			}
		}
	}

	// 3. 下发 NOTI 2193 同步 Elvenmere 进度
	plan = append(plan, outboundPacket{"elvenmere_info_sent", 0, 2193, protocol.ElvenmereInfo(nextFloor, maxCleared, w.activeDungeon.WeeklyRewards, w.activeDungeon.SeasonRewards)})

	return plan, nil
}

func (w *worldSession) leaveDungeon() ([]outboundPacket, error) {
	if w == nil || w.role.ID == 0 {
		return nil, fmt.Errorf("leave dungeon without selected character")
	}
	if err := w.finishBlackPurgatoryQuota("refund"); err != nil {
		return nil, err
	}
	// Leaving the starting route settles it, whichever exit is taken, and
	// lands the character at the town position the source route names.
	if w.inTutorial {
		if e := w.settleTutorialReturn(); e != nil {
			return nil, e
		}
	}
	// Returning to town republishes this actor to the shared scene before the area
	// list is serialized, so the client learns who is standing there.
	w.enterArea()
	// Town state remains the last owned, persisted origin throughout the run.
	ua, e := w.userAreaPayload()
	if e != nil {
		return nil, e
	}
	area, e := w.areaPayload()
	if e != nil {
		return nil, e
	}
	state, e := protocol.UserState(w.role.WireID, protocol.UserStateTown)
	if e != nil {
		return nil, e
	}
	plan := []outboundPacket{{"dungeon_leave_ack", 1, 42, []byte{1}}, {"town_actor_state", 0, 3, state}, {"dungeon_return_area", 0, 23, ua}, {"dungeon_return_users", 0, 24, area}}
	if w.characters != nil {
		channel := [2]byte{}
		if w.channelType == 73 && w.blackPurgatory.created {
			channel = w.characters.ChannelContext
		}
		visual, err := w.characters.EntryBasicProbe(w.role, channel)
		if err == nil {
			plan = append(plan, outboundPacket{"town_actor_appearance_restored", 0, 2, visual})
		}
		// 本局内新写入了扩展装备槽解锁位：趁回城这次机会重建装备栏行对象，把 addition 接在 appearance 之后——与登录/进副本的帧序一致，玩家不必重登就能看到解锁。
		if w.slotUnlockDirty {
			if addition, addErr := w.characters.EntryAddition(w.role); addErr == nil {
				plan = append(plan, outboundPacket{"town_actor_addition_restored", 0, 2, addition})
				w.slotUnlockDirty = false
			} else {
				log.Printf("回城补发装备栏解锁失败：character=%d: %v", w.role.ID, addErr)
			}
		}
		wornUpdate, err := inventory.WornSpaceUpdate(w.role.State)
		if err == nil && len(wornUpdate) > 0 {
			plan = append(plan, outboundPacket{"town_worn_visuals_restored", 0, 14, wornUpdate})
		}
		// Return reconstructs the actor just as entry/loading does. Reapply
		// the owned source table and existing verified Clone row layouts,
		// restoring non-avatar slots after both absolute mode1 packets.
		reset, full, enabled, cloneErr := w.characters.CloneReattachPackets(w.role)
		if cloneErr != nil {
			return nil, cloneErr
		}
		if enabled {
			sources, sourceErr := cloneAvatarSourcePackets(w.role.State)
			if sourceErr != nil {
				return nil, sourceErr
			}
			restore, restoreErr := inventory.NonAvatarWornSpaceUpdate(w.role.State)
			if restoreErr != nil {
				return nil, restoreErr
			}
			plan = append(plan, sources...)
			plan = append(plan, outboundPacket{"town_clone_detached", 0, 2, reset}, outboundPacket{"town_clone_reattached", 0, 2, full})
			if len(restore) > 0 {
				plan = append(plan, outboundPacket{"town_nonavatar_worn_restored", 0, 14, restore})
			}
		}
		if inventory.HasEquippedCreature(w.role.State) {
			clPayload, err := inventory.CreatureListPayload(w.role.State)
			if err == nil {
				plan = append(plan, outboundPacket{"town_creature_list_restored", 0, 105, clPayload})
				growth, err := inventory.CreatureGrowthPayload(w.role.State)
				if err == nil {
					plan = append(plan, outboundPacket{"town_creature_growth_restored", 0, 102, growth})
				}
			}
		}
	}
	// 矿区死亡由客户端本地角色处理，不一定有普通CMD40记录。
	if w.bleedingMineStart != nil || (w.pilotDeath != nil && w.pilotDeath.Dead) {
		if w.pilotDeath != nil {
			w.pilotDeath.Dead = false
		}
		// state 1 + 满 hp/mp：只翻 state 会把角色以 0% 血蓝送回城镇（实机 2026-10-04
		// 蔚蓝号：玩家回城后一直 0%、客户端弹收费的 Stamina Recovery 服务）。
		if reviveState, err := protocol.PlayerReviveState(w.role.WireID); err == nil {
			plan = append(plan, outboundPacket{"town_actor_revived", 0, 32, reviveState})
		}
	}
	if w.bleedingMineStart != nil {
		ready := bleedingMinePreparation()
		ready.Name = "赤红铁矿开战会话结束"
		plan = append(plan, ready)
	}
	if w.channelType == 73 && w.blackPurgatory.prepared {
		plan = append(plan, outboundPacket{"黑鸦挑战退出", 0, 1994, protocol.BlackPurgatoryEntryInfo(0, 0)})
		w.blackPurgatory.prepared, w.blackPurgatory.loaded = false, false
		w.blackPurgatory.deadline = time.Time{}
	}
	// 蔚蓝号通关后的收尾：官服在 CMD72 的应答之后补一帧 N249
	//（FINISH_VILLAGE_MONSTER_FIGHTING，#698），私服全仓没有这个 opcode。
	// 只在「这一局已经通关」时补；撤退/中途离开不发。
	if w.channelType == azureMainChannelType && w.activeDungeon != nil && w.activeDungeon.Completed() {
		plan = append(plan, outboundPacket{"azure_main_finish_fighting", 0, 249, protocol.AzureMainFinishFighting()})
	}
	// Commit the Odyssey cleared-dungeon ledger (mgr+2476) here on town-return rather than
	// in the clear burst: NOTI2856 is the client's ONLY writer of that ledger, and the 4125
	// chapter-reward banner needs the just-cleared id to still be absent from it while the
	// player is on the settlement panel. Advancing it on return shows the map as completed
	// without forcing a character re-select.
	if w.progression != nil && w.progression.Odyssey != nil && w.activeDungeon != nil && w.activeDungeon.Definition.Odyssey {
		if journal, e := w.progression.OdysseyProgressPayload(w.role); e == nil {
			plan = append(plan, outboundPacket{"odyssey_journal_updated_on_return", 0, 2856, journal})
		} else {
			log.Printf("Odyssey journal town-return payload failed: character=%d: %v", w.role.ID, e)
		}
	}
	return appendBuffEnhancementRestore(plan, w.characters, w.role, "town_buff_enhancement_restored")
}

func (w *worldSession) returnFromDungeonSelection(p []byte) ([]outboundPacket, error) {
	if len(p) != 0 || !w.selectingDungeon || w.activeDungeon != nil {
		return nil, fmt.Errorf("return requires owned dungeon selection")
	}
	plan, e := w.leaveDungeon()
	if e != nil {
		return nil, e
	}
	plan[0] = outboundPacket{"dungeon_selection_return", 0, 132, protocol.DungeonSelectionReturn()}
	return plan, nil
}

// fatalDropFailure classifies a failed drop roll for an already-confirmed death.
//
// A coverage gap - the imported model has no row for this monster's level - is not
// fatal: the death is a fact the client reported, while the drop is the server's own
// choice, and withholding the report over a gap leaves the client's monsters alive and
// the gate unopened (2026-09-26 border-of-attunement, and the FFFF killer arm in
// dungeon.ConfirmDeath before it). Every other failure is a defect of the model
// itself and must still fail the request, so that a real bug cannot hide behind
// "this monster simply paid nothing".
func fatalDropFailure(err error) error {
	if err == nil || errors.Is(err, loot.ErrOutOfDropRange) {
		return nil
	}
	return err
}

// noteDropGap records that a confirmed death paid nothing because the imported drop
// model does not cover the monster. The death itself is already applied; this only
// keeps the coverage gap visible instead of letting loot vanish quietly.
func (w *worldSession) noteDropGap(event func(map[string]any), entity uint16, e error) {
	if event == nil {
		return
	}
	fields := map[string]any{"kind": "drop_roll_skipped", "entity": entity, "reason": e.Error()}
	if w.activeDungeon != nil {
		for _, m := range w.activeDungeon.Monsters {
			if m.Entity == entity {
				fields["level"] = m.Level
				fields["rank"] = m.Rank
				fields["template"] = m.Template
				break
			}
		}
	}
	event(fields)
}

// noteOmenClear 把最近一次征兆结算记进事件流。玩家报告的「这把给了什么」应当
// 能从日志直接读出来，而不是靠反推掉落物属于哪一档。账本按自增序号去重，所以
// 同一场里其余怪物的死亡不会重复报同一条。
func (w *worldSession) noteOmenClear(event func(map[string]any)) error {
	if w.drops == nil || w.drops.Omen == nil {
		return nil
	}
	outcome, ok := w.drops.Omen.Last(w.role.ID)
	if !ok || outcome.Seq == w.omenReported {
		return nil
	}
	w.omenReported = outcome.Seq
	// 落库：持有数写回角色存档，满档结算额外置「下一场该出隐藏 BOSS」（见 omen_state.go）。
	// 失败往上抛 —— 掉落已经按结算结果算出来了，静默丢掉这次推进会让存档和玩家看到的
	// 东西互相矛盾。
	if err := w.noteOmenSettlement(outcome); err != nil {
		return err
	}
	if event == nil {
		return nil
	}
	fields := map[string]any{
		"kind":    "omen_clear",
		"dungeon": outcome.Dungeon,
		"held":    outcome.Held,
		"after":   outcome.After,
		"gained":  outcome.Gained,
		"paid":    outcome.Paid,
		"stage":   outcome.Stage,
	}
	if len(outcome.Awards) > 0 {
		ids := make([]uint32, 0, len(outcome.Awards))
		for _, a := range outcome.Awards {
			ids = append(ids, a.Template)
		}
		fields["templates"] = ids
	}
	event(fields)
	return nil
}

func (w *worldSession) monsterDeath(p []byte, event func(map[string]any)) ([]outboundPacket, error) {
	if w.activeDungeon == nil {
		return nil, fmt.Errorf("death without active run")
	}
	r, e := protocol.DecodeMonsterDeath(p)
	if e != nil {
		return nil, e
	}
	confirmed, e := w.activeDungeon.ConfirmDeath(r.Entity, r.Killer, w.role.WireID)
	if e != nil {
		return nil, e
	}
	// A monster the boss took with it is confirmed dead so the room can
	// clear, but it was not killed by this character: it pays no drops and
	// no experience. Both are skipped rather than rolled and discarded, so
	// nothing is charged against the run's drop budget either.
	unowned := w.activeDungeon.Unowned[uint16(r.Entity)]
	blackBoss := loot.BlackPurgatoryBossDeath(w.activeDungeon, uint16(r.Entity))
	if blackBoss {
		if err := w.freezeBlackPurgatoryRewards(); err != nil {
			return nil, err
		}
	}
	// [ISPINS-ARENA-BOSS] 伊斯大陆死亡批次（next79 §24）：官服 s4 实证
	// （c2s op=39 帧 335/392/441/485）对 boss 死亡上报的应答只有 16B 常量
	// N38（<u32 entity> <4B零> <5B token> <3B零>），无 39-ack、无 N37 经验
	// 推送、无 200B 掉落实体语法。私服 generic 批次发出这 3 帧后客户端
	// 1.2s 内 op=682 闪退（2026-10-03 五测实证）。
	if w.ispins != nil && w.activeDungeon != nil {
		plan := []outboundPacket{
			// N38 尾 5B token 官服按阶段各不相同（next79 §26），
			// 用当前 run 的阶段号回放对应 nonce。
			{"monster_death_confirmed", 0, 38, protocol.IspinsMonsterDeathConfirmed(r.Entity, w.ispins.stage)},
		}
		completed, err := w.completeDungeon()
		if err != nil {
			w.completionErr = err
			return plan, nil
		}
		return append(plan, completed...), nil
	}
	plan := []outboundPacket{{"monster_death_ack", 1, 39, []byte{1}}}
	var newDrops []protocol.SceneDrop
	if !w.deathSent[uint16(r.Entity)] {
		body := protocol.MonsterDeathConfirmed(uint16(r.Entity))
		// 军团本（维纳斯/伊斯/苏醒之森）BOSS 击杀不掉落任何物品：官服口径只有翻牌
		// 界面给奖励，地面金币/装备掉落是普通副本机制。在此入口整体排除，
		// 避免 w.drops.Death 为军团 BOSS roll 出地面掉落。
		if w.loot != nil && (!unowned || blackBoss) && w.venus == nil && w.ispins == nil && w.forest == nil {
			if w.drops == nil || w.drops.Run != w.activeDungeon.RunID {
				// Drops span every job's gear at every level by design; that
				// breadth is a feature, not a bug, so the pool is not narrowed
				// to what this character can wear.
				dropCatalog := w.loot.Catalog
				if len(w.loot.DropCatalog.Items) > 0 {
					dropCatalog = w.loot.DropCatalog
				}
				w.drops = loot.NewSession(dropCatalog, w.loot.Tables, w.loot.Rules, w.loot.Equipment, w.activeDungeon.RunID, w.account, w.role.ID, w.role.WireID)
				if w.activeDungeon.Definition.Odyssey {
					w.drops.Currency = w.loot.Currency
					w.drops.ChapterDrop = w.loot.ChapterDrop
				}
				w.drops.Attunement = w.loot.Attunement
				w.drops.RewardBoxes = w.loot.RewardBoxes
				w.drops.Omen = w.loot.Omen
				// 天平档位：本场进本时由 oathInfoPackets 算好（见 oath_info.go 的
				// oathTierRun）。它与征兆是两条平行线，各自发放互不抑制。
				w.drops.OathTier = w.oathTierRun
				if w.loot.Omen != nil && w.omenHeldReady {
					// 本场开始时的持有数：-omen-state 时来自角色存档
					// （loadOmenRunState），否则来自 -omen-hold 诊断。账本本身是内存的，
					// 所以新的一场必须重新预载，否则会沿用上一场结算后的值。
					w.loot.Omen.Set(w.role.ID, w.omenHeldRun)
				} else if w.loot.Omen != nil && !w.omenHoldApplied && w.omenHold >= 0 {
					// 诊断入口，每个会话只应用一次：放到指定阶段后就交回正常的
					// 累积/结算路径，免得每进一次副本都被拽回同一格。
					w.loot.Omen.Set(w.role.ID, uint32(w.omenHold))
					w.omenHoldApplied = true
				}
				store := w.store
				if store == nil && w.characters != nil {
					store = w.store
				}
				if store != nil {
					ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
					if hasGrowth, _ := store.HasActivePremium(ctx, w.account, database.PremiumGrowth, time.Now()); hasGrowth {
						w.drops.QuestDropBonusPercent = 20
					}
					cancel()
				}
			}
			w.drops.BlackPurgatory = w.loot.BlackPurgatory
			w.drops.BlackPurgatoryPlan = w.cardPlan
			rows, err := w.drops.Death(w.activeDungeon, uint16(r.Entity))
			if actor, known := w.activeDungeon.HellPartyReward(uint16(r.Entity)); known && confirmed {
				errText := ""
				if err != nil {
					errText = err.Error()
				}
				event(map[string]any{"kind": "hell_party_entity_death", "entity": r.Entity, "map": w.activeDungeon.Room.Map, "group": actor.Group, "order": actor.Order, "reward_rolls": actor.RewardRolls, "hell_monster": actor.HellMonster, "drop_percent": w.drops.Catalog.HellPartyDropPercent, "drops": len(rows), "skipped": w.drops.Skipped[uint16(r.Entity)], "error": errText})
			}
			if fatal := fatalDropFailure(err); fatal != nil {
				return nil, fatal
			}
			if err != nil {
				// Coverage gap: the imported model does not reach this monster, so the
				// death stands and pays nothing. See fatalDropFailure.
				w.noteDropGap(event, uint16(r.Entity), err)
				rows = nil
			}
			body, err = protocol.MonsterDeathDrops(uint16(r.Entity), rows)
			if err != nil {
				return nil, err
			}
			if err := w.noteOmenClear(event); err != nil {
				return nil, err
			}
			newDrops = rows
		}
		plan = append(plan, outboundPacket{"monster_death_confirmed", 0, 38, body})
		// 源 [boss room entrance condition] 的猎杀目标死亡后补发 NOTI312。
		// 客户端红柱门每帧 tick（14614E440）在 dungeon+0xC70!=0 时只认
		// dungeon+8056，而该字节全工程唯一写入点是 NOTI312 handler
		// 1452FF500 —— 不发这个包，门永远不会播放开门动画（静态取证
		// 20261004，attempt 1/3 命中；2026-10-04 实机确认红柱亮起）。外层 !deathSent 保证每实体每次死亡只发一帧；
		// confirmed 为假（重复死亡/非本会话归属）时不发。
		if confirmed {
			for _, m := range w.activeDungeon.Monsters {
				if uint16(m.Entity) != uint16(r.Entity) {
					continue
				}
				for _, id := range w.activeDungeon.Definition.BossEntranceConditionIDs {
					if m.Template == id {
						plan = append(plan, outboundPacket{"pass_gate_condition_completed", 0, 312,
							protocol.BossRoomPassGateCompleted(id)})
					}
				}
				break
			}
		}
	}
	if confirmed && w.quests != nil && !unowned {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		grant, err := (&workflow.QuestService{Store: w.store, Quest: w.quests}).GrantSeekingMonsterItems(ctx, w.role, w.activeDungeon, uint16(r.Entity))
		if err != nil {
			return nil, err
		}
		if len(grant.Items) > 0 {
			grant.Role.WireID = w.role.WireID
			w.role = grant.Role
			bag, err := inventory.ReadBag(w.role.State)
			if err != nil {
				return nil, err
			}
			seen := map[uint16]bool{}
			var rows [][protocol.CurrentItemRecordSize]byte
			for _, item := range grant.Items {
				for _, slot := range item.Slots {
					if seen[slot] {
						continue
					}
					row, ok := bag.RowAt(slot)
					if !ok {
						return nil, fmt.Errorf("quest item destination slot %d missing", slot)
					}
					seen[slot] = true
					rows = append(rows, row)
				}
			}
			update, err := protocol.InventoryUpdate(rows)
			if err != nil {
				return nil, err
			}
			plan = append(plan, outboundPacket{"seeking_items_granted", 0, 14, update})
		}
		if grant.Advanced {
			active, err := w.quests.Active(ctx, w.role)
			if err != nil {
				return nil, err
			}
			triggers, err := protocol.QuestTriggers(active)
			if err != nil {
				return nil, err
			}
			plan = append(plan, outboundPacket{"seeking_quest_triggers", 0, 291, triggers})
		}
	}
	if confirmed && w.quests != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		advanced, err := w.quests.EnemyDeath(ctx, w.role, w.activeDungeon, uint16(r.Entity))
		if err == nil && advanced {
			var active []protocol.ActiveQuest
			active, err = w.quests.Active(ctx, w.role)
			if err == nil {
				var triggers []byte
				triggers, err = protocol.QuestTriggers(active)
				if err == nil {
					plan = append(plan, outboundPacket{"enemy_hunt_quest_triggers", 0, 291, triggers})
				}
			}
		}
		cancel()
		if err != nil {
			return nil, err
		}
	}
	if w.progression != nil && !unowned {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		previousLevel := w.level
		saved, _, err := w.progression.Monster(ctx, w.role, w.activeDungeon, uint16(r.Entity))
		cancel()
		if err != nil {
			return nil, err
		}
		// Preserve the current scene identity; storage's wire column is a
		// durable roster identity rather than a new scene allocation.
		saved.WireID = w.role.WireID
		p, err := character.ExperiencePayload(saved)
		if err != nil {
			return nil, err
		}
		w.role = saved
		w.level = p[0]
		plan = append(plan, outboundPacket{"monster_experience_updated", 0, 37, p})
		if w.level != previousLevel {
			skills, err := w.automaticSkillRefresh()
			if err != nil {
				return nil, err
			}
			plan = append(plan, skills...)
		}
		if w.quests != nil && w.level != previousLevel {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			available, err := w.availableQuestPayload(ctx)
			cancel()
			if err != nil {
				return nil, err
			}
			plan = append(plan, outboundPacket{"level_available_quests", 0, 21, available})
		}
	}
	if w.activeDungeon.HellPartyCleared() && !w.activeDungeon.HellClearSent {
		plan = append(plan, outboundPacket{"hell_party_clear_sent", 0, 777, protocol.HellPartyClear()})
		w.activeDungeon.HellClearSent = true
	}
	// 维纳斯阶段清怪投影：最后一只战斗怪确认死亡后推进权威 N2655（客户端
	// 据此直进下一阶段，见 venusStageProjection）。
	plan = append(plan, w.venusStageProjection(event)...)
	completed, err := w.completeDungeon()
	if err != nil {
		// The death acknowledgement and confirmation are already in plan.
		// Completion failure must not discard the client's death evidence.
		w.completionErr = err
		return plan, nil
	}
	plan = append(plan, completed...)
	// 必须先通知生成地面物品，再发送已有拾取通知；自动领取不发送 CMD43 应答。
	return append(plan, w.autoPickupDrops(newDrops)...), nil
}

func (w *worldSession) bossCheck(p []byte) ([]outboundPacket, error) {
	r, err := protocol.DecodeBossCheck(p)
	if err != nil {
		return nil, err
	}
	if err = w.activeDungeon.BossCheck(r, w.role.WireID); err != nil {
		return nil, err
	}
	return w.completeDungeon()
}

func (w *worldSession) completeDungeon() ([]outboundPacket, error) {
	if w.moon.owner != nil {
		return nil, nil
	} // Moon final death owns its completion.
	if !w.activeDungeon.Completed() || w.completionSent {
		return nil, nil
	}
	if w.bleedingMineStart != nil {
		return w.completeBleedingMineStage()
	}
	// 伊斯大陆结算链（next78 §1.4）：N31 阶段 token → N2256 → N2252 →
	// N2255 clear → N1658 → N2253 → N2254。阶段推进由 CMD2046 分支处理。
	if w.ispins != nil {
		return w.completeIspinsStage()
	}
	// 维纳斯阶段本：非终点关走转阶段（CMD2062 直进），completeDungeon 返回 nil；
	// 终点关由 completeVenusStage 发军团翻牌链（N31→N2252→N2253，仿伊斯），
	// 绝不走通用结算（CMD46→N34/N35/N261+8张牌）。
	if w.venus != nil && w.activeDungeon != nil && legion.IsVenusStageDungeon(w.activeDungeon.Definition.ID) {
		return w.completeVenusStage()
	}
	// 苏醒之森阶段本：清怪即通关投影（N31→N2→N2563 cleared→N9，官服
	// 21:43:02 时序），客户端随后以 CMD46 触发下一关作战窗（forestResult），
	// 不走通用结算，也没有维纳斯式 CMD2062 直进。
	if w.forest != nil && w.activeDungeon != nil && legion.IsForestStageDungeonAny(w.activeDungeon.Definition.ID) {
		return w.completeForestStage()
	}
	if w.channelType == azureMainChannelType {
		return w.completeAzureMain()
	}
	if err := w.freezeBlackPurgatoryRewards(); err != nil {
		return nil, err
	}
	if err := w.finishBlackPurgatoryQuota("clear"); err != nil {
		return nil, err
	}
	var plan []outboundPacket
	if w.progression != nil && w.progression.Odyssey != nil && w.activeDungeon.Definition.Odyssey {
		beforeBag, e := inventory.ReadBag(w.role.State)
		if e != nil {
			return nil, e
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		saved, _, e := w.progression.OdysseyClear(ctx, w.role, w.activeDungeon)
		cancel()
		if e != nil {
			return nil, e
		}
		saved.WireID = w.role.WireID
		body, e := character.ExperiencePayload(saved)
		if e != nil {
			return nil, e
		}
		w.role, w.level = saved, body[0]
		plan = append(plan, outboundPacket{"odyssey_clear_target_level", 0, 37, body})
		skills, e := w.automaticSkillRefresh()
		if e != nil {
			return nil, e
		}
		plan = append(plan, skills...)
		// No clear-burst NOTI2856 here: the client writes mgr+2476 ONLY from this packet,
		// and both the 4125 chapter-reward banner (pending = just-cleared id NOT in +2476)
		// and the Odyssey map unlock frontier read that same ledger. Committing it now would
		// swallow the banner. Retail sends 2856 only at login/entry, so we let entry_flow.go's
		// odyssey_journal_restored advance the ledger on the next re-entry.
		ctx, cancel = context.WithTimeout(context.Background(), 5*time.Second)
		gifted, applied, _ := w.progression.OdysseyGifts(ctx, w.role)
		if w.progression != nil && w.progression.Chapters != nil {
			chaptered, chapterApplied, pending := w.progression.OdysseyChapterRewards(ctx, gifted)
			gifted, applied = chaptered, applied || chapterApplied
			for _, err := range pending {
				log.Printf("Odyssey chapter reward pending: character=%d: %v", gifted.ID, err)
			}
		}
		mailed, _, mailErr := w.progression.OdysseyHonorMail(ctx, gifted)
		gifted = mailed
		if mailErr != nil {
			log.Printf("Odyssey honor mail pending: character=%d: %v", gifted.ID, mailErr)
		}
		cancel()
		w.role = gifted
		if applied {
			bag, e := inventory.ReadBag(gifted.State)
			if e != nil {
				return nil, e
			}
			update, e := protocol.InventoryRestore(bag.Rows(), bag.Expansion)
			if e != nil {
				return nil, e
			}
			plan = append(plan, outboundPacket{"odyssey_milestone_inventory", 0, 13, update})
		}
		// 本关解锁了扩展装备槽时，就地重喂一次装备栏，让客户端**当场**重建装备栏 ——
		// 否则玩家必须重登或重选角色才看得到解锁（槽位状态由装备栏行对象在构造期
		// 决定、运行期只读，取证见 analysis/tasks/next50-odyssey-expanded-equip-slot.md）。
		//
		// 帧组合与顺序完全复用 entry / 装备变更（equipment_flow.go）那两套通道：
		// id-13 重喂背包网格与 worn 模型，id-14 重喂 worn 槽窗口；**两者必须成对**，
		// 实测只发 id-13 会让槽位窗口变空。注意不要发 entry_addition（NOTI 2）——
		// 那是进图/登录帧，在副本内发会让客户端把装备栏显示清空（见该文档「重发的坑」）。
		if afterBag, e := inventory.ReadBag(w.role.State); e == nil && afterBag.ExpandEquipFlags != beforeBag.ExpandEquipFlags {
			// 装备栏挂锁只能由 EntryAddition 投影，而副本内重发它会把装备栏显示清空；所以这里只置脏标记，留到回城时补发（leaveDungeon）。
			w.slotUnlockDirty = true
			if bag, e := inventory.ReadBag(w.role.State); e == nil {
				if bagBody, e := protocol.InventoryRestore(bag.Rows()); e == nil {
					plan = append(plan, outboundPacket{"equipment_bag_resynced", 0, 13, bagBody})
				}
				if wornBody, e := inventory.WornPayload(w.role.State); e == nil && len(wornBody) > 0 {
					plan = append(plan, outboundPacket{"equipment_worn_resynced", 0, 13, wornBody})
				}
				if slots, e := inventory.EquipmentPayload(3, bag.Worn, false); e == nil {
					plan = append(plan, outboundPacket{"equipment_slots_updated", 0, 14, slots})
				}
			}
			if upd, e := inventory.WornSpaceUpdate(w.role.State); e == nil && len(upd) > 0 {
				plan = append(plan, outboundPacket{"equipment_worn_window_refreshed", 0, 14, upd})
			}
		}
	}
	if w.quests != nil && w.dungeons != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		active, err := w.quests.MapClear(ctx, w.role, w.activeDungeon, w.dungeons.Source.SaveIdentity())
		if err != nil {
			return nil, err
		}
		triggers, err := protocol.QuestTriggers(active)
		if err != nil {
			return nil, err
		}
		plan = append(plan, outboundPacket{"map_clear_quest_triggers", 0, 291, triggers})
	}
	if w.activeDungeon.CompletionNeedsBossCheck() {
		body, err := protocol.BossCheckConfirmed(w.activeDungeon.CompletionTarget())
		if err != nil {
			return nil, err
		}
		plan = append(plan, outboundPacket{"boss_check_confirmed", 0, 115, body})
	}
	plan = append(plan, outboundPacket{"dungeon_clear_enabled", 0, 31, protocol.DungeonClearEnabled()})
	if w.activeDungeon.Tournament != nil {
		reward, e := w.tournamentClear()
		if e != nil {
			return nil, e
		}
		plan = append(plan, outboundPacket{"tournament_clear_reward", 0, 374, reward})
	}
	// 隐藏 BOSS 的两种来源各自归位，都必须在「通关确认」之后 —— 掉线或退出不该
	// 吞掉已经攒到的那一次。
	cleared := w.oathProgressDungeon()
	if w.omenState {
		// 征兆线：这一场把进本时读到的「满档结算待出」标记兑现掉。见 omen_state.go。
		if e := w.clearOmenOrthaier(cleared); e != nil {
			return nil, e
		}
	} else if before, after, e := w.noteOathProgressClear(cleared); e != nil {
		// 旧通关保底（-oath-progress-clears，诊断保留）。
		return nil, e
	} else if w.oathProgressEnabled(cleared) {
		log.Printf("oath progress: dungeon %d clears %d -> %d (pity every %d)",
			cleared, before, after, w.oathProgressClears)
	}
	return plan, nil
}

func (w *worldSession) freezeBlackPurgatoryRewards() error {
	if w.activeDungeon == nil || w.activeDungeon.Definition.ID != blackPurgatorySquadDungeon || w.cardPlan != nil {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	var seed uint32
	if err := binary.Read(rand.Reader, binary.LittleEndian, &seed); err != nil {
		return err
	}
	cards, err := (&workflow.LootService{Store: w.store, Loot: w.loot}).FreezeBlackPurgatoryCards(ctx, w.role, w.activeDungeon, seed)
	if err != nil {
		return err
	}
	w.cardPlan = &cards
	log.Printf("黑鸦奖单已保存：角色=%d 挑战=%s 翻牌=%v 领主装备=%v 概率规则=%s", w.role.ID, cards.Run, cards.Items, cards.BossItems, cards.BossModel)
	return nil
}

// 场景/演出层的换房全部由客户端原生 CMD45 承担（实测 2026-10-05 贵族机要
// 100004968：进入演出图 100016356 用 45+p10=1，离开用普通 45）。历史上的
// interactDoor/sceneExitRequest 把 C2S38（USE_SKILL，见 dispatch 注释）误当
// 「点门」，导致演出层末图里每次放技能都合成跳房，已随该误认一并撤除。

func (w *worldSession) moveDungeonRoom(p []byte) (*dungeon.Session, []outboundPacket, error) {
	if w.activeDungeon == nil || w.dungeons == nil {
		return nil, nil, fmt.Errorf("room transition without active run")
	}
	r, e := protocol.DecodeDungeonRoomTransition(p)
	if e != nil {
		return nil, nil, e
	}
	return w.moveDungeonRoomDecoded(r)
}

// moveDungeonRoomDecoded 与 moveDungeonRoom 相同，但接受已经解码好的转换请求
// （客户端原生帧，或测试里按原生帧形态重建的请求）。
func (w *worldSession) moveDungeonRoomDecoded(r protocol.DungeonRoomTransition) (*dungeon.Session, []outboundPacket, error) {
	if w.activeDungeon == nil || w.dungeons == nil {
		return nil, nil, fmt.Errorf("room transition without active run")
	}
	var e error
	var next *dungeon.Session
	// [MERGE-20261005-LAYER-REVISIT-LAYER] 回头路走进「层序列已播完」的格子。
	layerRevisit := false
	if r.LayerChange {
		// 客户端主动换图（CMD45 p10=1）→ MoveScene：序列未完则推进层图，
		// 序列走完则前进到相邻格（出口方向判据见 dungeon.MoveScene）。
		next, e = w.activeDungeon.MoveScene(*w.dungeons, r)
	} else if r.Record[0] == 1 {
		next, e = w.activeDungeon.MoveScript(*w.dungeons, r)
		if e != nil {
			next, e = w.activeDungeon.Move(*w.dungeons, r.Position)
		}
	} else {
		next, e = w.activeDungeon.Move(*w.dungeons, r.Position)
		if e == nil {
			// 服务端房间保持在末张层图上（latestLayer 已是它），只改发包形态。
			layerRevisit = next.OnFinishedLayer()
		}
	}
	if e != nil {
		return nil, nil, e
	}
	// [MERGE-20260928-DIAG] 暂存场景换图的决策路径，由 main.go 的 dispatch 落进 events。
	w.sceneDiag = next.SceneDiagnostic()
	w.sceneDiagFrom, w.sceneDiagTo = w.activeDungeon.Room.Map, next.Room.Map
	var seed uint32
	if e = binary.Read(rand.Reader, binary.LittleEndian, &seed); e != nil {
		return nil, nil, e
	}
	// [MERGE-20260928-LAYER-SEQUENCE-EXIT] Position 取**目标房间自己的坐标**，而不是
	// 请求里的 r.Position。两者在正常路径上一致（Move/MoveScene/MoveScript 都只改
	// Map、不改 X/Y），但在「多张层图序列走完后改用 Move 前进到相邻房间」这条新路径
	// 上它们会不同：请求带的还是层图所在格的坐标 (0,2)，玩家却已经去了 (0,1)。
	// StartMap 把 Position 写成包的前两字节，客户端据此安放角色 —— 用错就等于把玩家
	// 放在地图外，实机表现是「角色不见了」（2026-09-28 贵族机要 100004968）。
	state := protocol.StartMapState{Position: [2]byte{next.Room.X, next.Room.Y}, Seed: seed, Map: next.Room.Map, Monsters: next.LivingMonsters(), HellPartyMode: next.HellPartyMode(), LayerChange: r.LayerChange, EncodeCreateTrigger: monsterCreateTriggerEnabled()}
	if resume, ok := w.activeDungeon.SourceLayerResume(*w.dungeons, r); ok && resume != w.activeDungeon.Room.Map {
		// Flag 2 clears the native layer ordinal at1452b7876; flag 0 only
		// selects the base descriptor and leaves the active layer unchanged.
		// Mode 0 retains the verified base actors and one-shot ACT state.
		state.LayerChange = false
		state.ExitLayer = true
		state.ReuseRoom = true
		state.Monsters = nil
	}
	if layerRevisit {
		// 层序列已经播完的格子被走回头路：上面通用分支给的 flag 0 不会清原生层序号
		// （1452b787f..7886 设完标志直接跳 LABEL93），客户端于是把末张层图的近景道具
		// 和 base 描述符拼在一起，远景 `[background animation]` 层没人装配 —— 实机
		// 2026-10-05 贵族机要「走回头路后房间背景全黑」。
		//
		// flag 1 + mode 0 才是「保住这一格层序号」的形态：原生把同格层索引前进并钳在
		// 最后一张（1452b77ee..1452b788b），按有效序号选中缓存里那张**层图**房间，
		// mode 0 在 1452b78f0 跳过建图与 ON START MAP 演出。attempt 1/3 的 flag 2 清掉
		// 序号后选的是 base 缓存 —— 背景不黑了但恢复成入场那间宫殿，内容选错房。
		// 这条包形态本服已在跑：`r.LayerChange && 目标图==当前图` 的层图往返
		// （实机安图恩讨伐战 100004950 的 164↔165）发的就是 flag 1 + mode 0。
		state.LayerChange = true
		state.ReuseRoom = true
		state.Monsters = nil
		if state.Transition == nil {
			// flag 1 要求带换图记录；这一格的回头请求不带落点覆盖，用 StartMap
			// 的原生默认记录（与同局普通格回头那包的记录逐字节一致）。
			rec := [18]byte{0, 0, 0, 0, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0, 0, 0, 0, 0, 0}
			state.Transition = &rec
		}
	}
	if r.LayerChange && next.Room.Map == w.activeDungeon.Room.Map {
		state.ReuseRoom = true
		state.Monsters = nil
	}
	if _, visited := w.activeDungeon.Visited[next.Room.Map]; visited && (next.Definition.Odyssey || next.IsResumedSceneBase() || next.Definition.IndividualMapMovement && next.Definition.MoveMapEvenEnemy) && !r.LayerChange {
		state.ReuseRoom = true
		state.Monsters = nil
	}
	// [MERGE-20260928-TRANSITION-DEFAULT] 有换图记录就照发；客户端帧不带记录
	// （副本不在 scenes 路由表里，如「无信草原」100004781）时 Record 是全零 ——
	// 这时**不能**把全零发出去：StartMap 的默认换图记录是
	// `0000ffffffffffffffff000000000000`（native1452b7494），全零会覆盖它，客户端
	// 拿零落点安置角色，表现为「角色不显示」（实机 2026-09-28）。LayerChange 又要求
	// Transition 必须存在，所以回落到那份默认记录。
	if r.LayerChange || r.Record[0] == 1 {
		rec := r.Record
		if rec == ([18]byte{}) {
			// [MERGE-20260928-START-LAYER-EXIT] 这一格的原记录只有客户端进层图
			// 那一包里有 —— 取留存的那份。落点错位的话紧接的第二段剧情一开就崩
			// （实机 2026-09-28 晦月湖）。
			if entry, ok := next.SceneEntryRecord(); ok {
				rec = entry
			} else {
				rec = [18]byte{0, 0, 0, 0, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0, 0, 0, 0, 0, 0}
			}
		}
		state.Transition = &rec
	}
	body, e := protocol.StartMap(state)
	if e != nil {
		return nil, nil, e
	}
	return next, []outboundPacket{{"dungeon_move_ack", 1, 45, []byte{1}}, {"dungeon_next_map_sent", 0, 29, body}}, nil
}

// oathDirectEntryActive 报告本连接当前是否命中「誓约进图直发」。
// 条件：有角色服务和存储 ∧ **穿槽位 47 誓约核心**
// （`EquippedOathSelection` 在未穿槽位 47 时返回 ItemID == 0）。
func (w *worldSession) oathDirectEntryActive(ctx context.Context) (bool, error) {
	if w.characters == nil || w.store == nil || w.role.ID == 0 {
		return false, nil
	}
	oathCtx, oathCancel := context.WithTimeout(ctx, 5*time.Second)
	defer oathCancel()
	selected, err := w.store.EquippedOathSelection(oathCtx, w.account, w.role.ID)
	if err != nil {
		return false, err
	}
	return selected.ItemID != 0, nil
}

// oathDirectEntryPackets 构造要提前到 NOTI29 之前的三项（13/14/2839）。未命中时返回空切片。
func (w *worldSession) oathDirectEntryPackets(ctx context.Context) ([]outboundPacket, error) {
	active, err := w.oathDirectEntryActive(ctx)
	if err != nil || !active {
		return nil, err
	}
	wornSnapshot, err := inventory.WornPayload(w.role.State)
	if err != nil {
		return nil, err
	}
	out := []outboundPacket{{"dungeon_worn_equipment_direct", 0, 13, wornSnapshot}}
	if wornUpdate, updErr := inventory.WornSpaceUpdate(w.role.State); updErr == nil && len(wornUpdate) > 0 {
		out = append(out, outboundPacket{"dungeon_worn_visuals_direct", 0, 14, wornUpdate})
	}
	selection, err := w.dungeonOathSelectionPacket(ctx)
	if err != nil {
		return nil, err
	}
	out = append(out, selection)
	return out, nil
}
