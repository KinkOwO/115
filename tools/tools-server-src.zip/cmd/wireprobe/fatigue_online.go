package main

import (
	"context"
	"dfolan/internal/game/protocol"
	"dfolan/internal/game/wire"
	"io"
	"time"
)

type clientRead struct {
	frame wire.Frame
	err   error
}

// A single uninterrupted reader owns framing. Timer events never interrupt a
// partially received encrypted frame, and only the session loop writes replies.
func clientFrames(r io.Reader, done <-chan struct{}) <-chan clientRead {
	ch := make(chan clientRead)
	go func() {
		defer close(ch)
		for {
			f, e := wire.ReadClient(r)
			select {
			case ch <- clientRead{f, e}:
			case <-done:
				return
			}
			if e != nil {
				return
			}
		}
	}()
	return ch
}

func (w *worldSession) refreshDailyFatigue(now time.Time) ([]byte, error) {
	if w == nil || w.fatigue == nil || w.role.ID == 0 {
		return nil, nil
	}
	day := w.fatigue.Day(now)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	limit, e := w.fatigue.DailyLimit(ctx, w.role.AccountID, now)
	if e != nil {
		return nil, e
	}
	// 同日也检查契约购买和到期；上限未变化时不写疲劳存档、不重复发包。
	if day <= w.lastFatigueDay && limit == w.lastFatigueLimit {
		return nil, nil
	}
	fp, e := w.fatigue.State(ctx, w.role.AccountID, w.role.ID, now)
	if e != nil {
		return nil, e
	}
	// 契约到期可能让已用值超过上限，仅限制显示，保留真实消耗供续费使用。
	p, e := protocol.Fatigue(min(fp.Used, fp.Limit), fp.Limit, fp.UsedMax)
	if e != nil {
		return nil, e
	}
	w.lastFatigueDay = fp.Day
	w.lastFatigueLimit = fp.Limit
	return p, nil
}
