package protocol

import (
	"encoding/binary"
	"fmt"
)

// StoryDigestLevel 对应 NOTI1370/0x1444f4410：一个小端 i32，表示上次回顾时的等级。
// 0x1444f6180 按该等级排除已经播放的章节；它与 NOTI2310 文字摘要无关。
func StoryDigestLevel(level uint32) ([]byte, error) {
	if level > 0x7fffffff {
		return nil, fmt.Errorf("剧情回顾等级超出范围")
	}
	return add32(nil, level), nil
}

// 143c671c0 sends one u16 scene ID. NOTI1352/143c65010 consumes a
// length-prefixed 5000-byte bitmap and unpacks exactly 40000 scene flags.
func DecodeCinematicSkip(p []byte) (uint16, error) {
	if len(p) != 2 && len(p) != 8 && len(p) != 16 {
		return 0, fmt.Errorf("cinematic request length")
	}
	if err := padding(p[2:], 16); err != nil {
		return 0, err
	}
	id := binary.LittleEndian.Uint16(p)
	if id >= 40000 {
		return 0, fmt.Errorf("cinematic scene outside bitmap")
	}
	return id, nil
}

func CinematicSkippedScenes(ids []uint16) ([]byte, error) {
	p := append(add32(nil, 5000), make([]byte, 5000)...)
	for _, id := range ids {
		if id >= 40000 {
			return nil, fmt.Errorf("cinematic scene outside bitmap")
		}
		p[4+int(id)/8] |= 1 << (id % 8)
	}
	return p, nil
}

// SynopsisReadTable 对应 NOTI2310/0x140f0e410：一个保留字节、i16 数量、i32 编号列表。
// 0x140f0f7e0 用该列表替换已读集合，再重新计算未读摘要。
func SynopsisReadTable(ids []uint32) ([]byte, error) {
	if len(ids) > 32767 {
		return nil, fmt.Errorf("剧情摘要已读记录过多")
	}
	p := add16([]byte{0}, uint16(len(ids)))
	seen := make(map[uint32]bool, len(ids))
	for _, id := range ids {
		if id > 0x7fffffff || seen[id] {
			return nil, fmt.Errorf("剧情摘要编号无效或重复：%d", id)
		}
		seen[id] = true
		p = add32(p, id)
	}
	return p, nil
}
