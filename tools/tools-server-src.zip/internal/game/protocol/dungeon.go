package protocol

import (
	"encoding/binary"
	"fmt"
)

// CMD15: normal town gate sends u32(0); the tutorial sender at146cce650
// uses a source dungeon ID instead. Slot1 pads the four-byte body to8.
func DecodeDungeonGate(p []byte) (uint32, error) {
	if len(p) != 8 {
		return 0, fmt.Errorf("dungeon gate requires four bytes padded to8")
	}
	if e := padding(p[4:], 8); e != nil {
		return 0, e
	}
	return binary.LittleEndian.Uint32(p), nil
}

// EnterDungeonSelection is NOTI27, handler145303260. This is the solo,
// non-relay path with no optional event/party collections. Scalar meanings
// beyond verified mode fields remain unnamed, rather than guessed IDs.
// The full 36-byte reader sequence is checked with the original native code.
func EnterDungeonSelection() []byte {
	p := []byte{0, 0, 0}      // first/relay/relay-extra, 1453032f6/307/7c4
	p = add32(add32(p, 0), 0) // 145303871/8ec
	p = append(p, 0)          // u16 collection, 145303ac3
	p = add32(p, 0)           // 145303b8f
	p = append(p, 0, 0, 0)    // u16 collections, 145303bc6/c38/d58
	p = add16(add16(p, 0), 0) // 145303f7b/fa2
	p = add32(p, 0)           // 145303fc7
	p = append(p, 0)          // mode flag, 145303ff4
	p = add32(p, 0)           // mode0, 145304033 (native clamps to0..1)
	p = add16(p, 0)           // 1453040b4
	return append(p, 0, 0)    // u32/u16 collections, 145304140/1b9
}

type DungeonSelection struct {
	ID         uint32
	Difficulty byte
	Extra      uint16
	Mode, Flag byte
	Party      uint16
	Reserved   uint32
	Tail       byte
	Quest      uint32
	Options    [2]byte
	Event      uint32
}

// 146d4a148..4d2: u32,u8,u16,u8,u8,u16,u32,u8,u32,u8,u8,u32.
func DecodeDungeonSelection(p []byte) (r DungeonSelection, e error) {
	if len(p) != 32 {
		return r, fmt.Errorf("select dungeon must contain26 bytes padded to32")
	}
	if e = padding(p[26:], 16); e != nil {
		return r, e
	}
	r.ID = binary.LittleEndian.Uint32(p)
	r.Difficulty = p[4]
	r.Extra = binary.LittleEndian.Uint16(p[5:])
	r.Mode = p[7]
	r.Flag = p[8]
	r.Party = binary.LittleEndian.Uint16(p[9:])
	r.Reserved = binary.LittleEndian.Uint32(p[11:])
	r.Tail = p[15]
	r.Quest = binary.LittleEndian.Uint32(p[16:])
	copy(r.Options[:], p[20:22])
	r.Event = binary.LittleEndian.Uint32(p[22:])
	return r, nil
}

type DungeonInfoState struct {
	ID               uint32
	Difficulty, Maze byte
	Boss             [2]byte
	Hell             *[2]byte
}

type DungeonDirectMove struct {
	ID, Difficulty uint32
	Option         uint32
	PositionMode   uint32
	Area           [4]uint32
	Mode           byte
	Record         [48]byte
}

// CMD2062：146d45d00 在 13 字节未初始化前缀后写入八个 u32 和一个 u8，
// 146d45ecf 按 46 字节发送，再由传输层补齐到 48。前缀不作为业务字段。
func DecodeDungeonDirectMove(p []byte) (r DungeonDirectMove, err error) {
	if len(p) != 48 {
		return r, fmt.Errorf("直接切图请求必须为 46 字节并补齐至 48 字节")
	}
	if err = padding(p[46:], 16); err != nil {
		return r, err
	}
	copy(r.Record[:], p)
	r.ID = binary.LittleEndian.Uint32(p[13:])
	r.Difficulty = binary.LittleEndian.Uint32(p[17:])
	r.Option = binary.LittleEndian.Uint32(p[21:])
	r.PositionMode = binary.LittleEndian.Uint32(p[25:])
	for i := range r.Area {
		r.Area[i] = binary.LittleEndian.Uint32(p[29+i*4:])
	}
	r.Mode = p[45]
	return r, nil
}

// NOTI2281：1452ac200 复制 38 字节；+13 为成功标记，+18 为落点模式，
// +22..+37 的四个 u32 经 146d4fae0 保存为新地图落点区域。
// 前缀和 +14 的字段未被该 reader 使用，保留零；目标副本由 NOTI28 指定。
func DungeonDirectMoveNotice(r DungeonDirectMove) []byte {
	p := make([]byte, 38)
	p[13] = 1
	binary.LittleEndian.PutUint32(p[18:], r.PositionMode)
	for i, value := range r.Area {
		binary.LittleEndian.PutUint32(p[22+i*4:], value)
	}
	return p
}

func DungeonInfo(s DungeonInfoState) []byte {
	p := add32(nil, s.ID)
	p = append(p, s.Difficulty)
	p = add16(p, 0)
	// NOTI28 writes boss XY to dungeon+1934/+193c, consumed by the
	// native room predicate145b34090 and path gate14614de00. The current
	// room belongs only in NOTI29. The following XY is the random-hell
	// location (145b27520);255/255 is the native absent sentinel1452a94b2.
	hell := [2]byte{255, 255}
	if s.Hell != nil {
		hell = *s.Hell
	}
	p = append(p, s.Maze, s.Boss[0], s.Boss[1], hell[0], hell[1], 0, 0)
	p = add16(add16(p, 0), 0)
	p = append(p, 0)
	p = add32(p, 0xffffffff)
	p = append(p, 0, 0, 0, 0, 0, 0, 0, 0)
	p = add16(add16(add16(p, 0), 0), 0)
	return add32(p, 0)
}

type DungeonMonster struct {
	Entity      uint16
	SourceIndex uint32
	Level       byte
	Template    uint32
	Rank        byte     // Original map parser1471e92ac..9368: normal0, champion1, super2, boss3.
	Team        uint32   // Current actor affiliation: source team0 friendly, default100 enemy.
	NonCombat   bool     // Source team0/dummy; still spawned for native cinematic scripts.
	SourceTail  [2]int32 // Map row fields6/7, retained separately from spawn count.
	APC         bool     // Fixed map AIC; uses ranks5..8 and its own source row index.
	// CreateTrigger 是该行在 map 里的 [monster create trigger] 原值。
	// 它是否会写进进图包由 StartMapState.EncodeCreateTrigger 决定；
	// 该字段的语义尚未确认，所以默认不编码。
	CreateTrigger byte
}
type StartMapState struct {
	ReuseRoom   bool
	LayerChange bool
	// ExitLayer clears the native layer ordinal before selecting the base cache
	// (1452b787f -> 1452b7876). Ordinary flag 0 leaves that ordinal unchanged.
	ExitLayer  bool
	Transition *[18]byte
	Position   [2]byte
	Seed, Map  uint32
	Monsters   []DungeonMonster
	// EncodeCreateTrigger 置位时，怪物记录里 Rank 之后那一格（原本恒为 0）
	// 改写实例的 CreateTrigger。默认 false 时输出与原先逐字节一致。
	EncodeCreateTrigger bool
}

func StartMap(s StartMapState) ([]byte, error) {
	if s.Map == 0 || len(s.Monsters) > 255 {
		return nil, fmt.Errorf("invalid start map")
	}
	if s.ReuseRoom && len(s.Monsters) != 0 {
		return nil, fmt.Errorf("cached room cannot initialize monsters")
	}
	if s.LayerChange && s.ExitLayer {
		return nil, fmt.Errorf("conflicting layer transition modes")
	}
	p := append([]byte{}, s.Position[0], s.Position[1], 0)
	if s.LayerChange || s.ExitLayer {
		if s.Transition == nil {
			return nil, fmt.Errorf("layer transition record required")
		}
		p[2] = 1
		if s.ExitLayer {
			p[2] = 2
		}
	}
	p = add32(p, s.Seed)
	p = append(p, 0, 0)
	p = add32(p, 0xffffffff)
	// Native transition record defaults at1452b7494..4a7, consumed18 bytes.
	p = append(p, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0)
	if s.Transition != nil {
		copy(p[13:31], s.Transition[:])
	}
	// Native1452b78f0 skips map/spawn rows for mode0. The constructor at
	// 145b235b0 then retains the cached map and its one-shot ACT triggers.
	if s.ReuseRoom {
		return append(p, 0, 0, 255), nil // mode0, no groups, no other-party actor
	}
	p = append(p, 1)
	p = add32(p, s.Map)
	p = append(p, byte(len(s.Monsters)))
	seen := map[uint16]bool{}
	for _, m := range s.Monsters {
		// Fixed APCs address the current map's [ai character] table with
		// SourceIndex 0..63. Native145b20dc0 has a separate, explicit 10000
		// branch for an APC that has no row in the current map: it creates the
		// AIC by Template, applies the packet Team and enables following. This
		// is the retail path for carrying a story companion into the next room;
		// reusing its old map-table index there dereferences the wrong table.
		validAPCSource := m.SourceIndex < 64 || m.SourceIndex == 10000
		validRank := !m.APC && m.Rank <= 3 || m.APC && m.Rank >= 5 && m.Rank <= 8 && validAPCSource
		if m.Entity == 0 || m.Entity == 65535 || seen[m.Entity] || m.Template == 0 || !validRank || m.Team > 0x7fffffff {
			return nil, fmt.Errorf("invalid monster identity")
		}
		seen[m.Entity] = true
		// 1452b7c3c -> 145b0d910: the SECOND u16 is MonsterUniqueId.
		// MonsterLevel is the first byte after the template u32. Confirmed
		// against the same constructor and named log at 1452b6492.
		p = add32(add16(p, 0), m.SourceIndex)
		p = add32(add16(p, m.Entity), m.Template)
		createTrigger := byte(0)
		if s.EncodeCreateTrigger {
			createTrigger = m.CreateTrigger
		}
		p = append(p, m.Level, m.Rank, createTrigger, 0, 255)
		// 145b0d910 record+40 ->145b219d0 ->145b144f0 ->vtable+a40
		// ->145dd6080 ->145d87580 writes actor+f10 (team), not HP.
		p = add32(p, m.Team)
		p = append(p, 0)
	}
	return append(p, 0, 0, 0, 255), nil // no extra APC/group rows; no other-party actor
}
func DungeonLoaded() []byte { return []byte{0, 0, 0, 0, 0} }

// NOTI132, native1452aee40, normal solo return-to-town branch.
func DungeonSelectionReturn() []byte { return []byte{0} }

// NOTI 2193 (0x0891, ENUM_NOTIPACKET_ELVENMERE_INFO), native 142223F70 -> 14222B360.
// Payload is exactly 203 bytes:
//
//	Byte 0: status/version (0 or 1)
//	Byte 1: max cleared floor (1..100, 0 if none)
//	Byte 2: current floor (1..100)
//	Bytes 3..102 (100 bytes): weekly clear/reward status for floors 1..100
//	Bytes 103..202 (100 bytes): season clear/reward status for floors 1..100
func ElvenmereInfo(currentFloor, maxCleared byte, weeklyRewards, seasonRewards [100]byte) []byte {
	p := make([]byte, 203)
	p[0] = 0 // mode/status
	p[1] = maxCleared
	p[2] = currentFloor
	copy(p[3:103], weeklyRewards[:])
	copy(p[103:203], seasonRewards[:])
	return p
}

type MonsterDeathReport struct {
	Entity uint32
	Killer uint16
}

// EplpRechallenge is the NOTI 261 body (ENUM_NOTIPACKET_EPLP_RECHALLENGE -
// the opcode name comes from analysis/dumps/opcodes.tsv). The client reads a
// single byte into the settlement panel's retry state: 9 lights the
// "continue challenge" entry and the right-edge arrow, 1 leaves it greyed.
//
// It is sent after NOTI 35 because the panel is built from that reward; a
// patch pushed before it has nothing to attach to. Only 9/1 are ever sent -
// do not pass arbitrary values, the client switches on them.
//
// Origin: the outside repair document describes the same single byte and the
// same two values. Our own evidence for the opcode name is the dump above;
// the two values still need live confirmation on this client build.
const (
	// EplpRechallengeReady enables the retry entry (another run is allowed).
	EplpRechallengeReady byte = 9
	// EplpRechallengeBlocked leaves it greyed out (fatigue or entry refused).
	EplpRechallengeBlocked byte = 1
)

func EplpRechallenge(state byte) []byte { return []byte{state} }

func DecodeMonsterDeath(p []byte) (MonsterDeathReport, error) {
	// Native145dc9bf4..145dca2af. The following combat/check fields are opaque;
	// do not interpret them as HP, damage, item IDs or authoritative rewards.
	if len(p) < 64 || len(p) > 4096 || len(p)%8 != 0 {
		return MonsterDeathReport{}, fmt.Errorf("invalid monster death envelope")
	}
	if 31+int(p[30])*14+7 > len(p) {
		return MonsterDeathReport{}, fmt.Errorf("truncated death participant list")
	}
	return MonsterDeathReport{binary.LittleEndian.Uint32(p), binary.LittleEndian.Uint16(p[4:])}, nil
}

// The no-item NOTI38 branch is independently consumed by1452bb930.
// Drops are a separate generated outcome; this response does not grant any.
func MonsterDeathConfirmed(entity uint16) []byte {
	return append(add16(add16(nil, entity), 0), 0, 0, 255, 0)
}

func DecodeMoveDungeonRoom(p []byte) ([2]byte, error) {
	// Native144d35022..144d35507 writes155 bytes: target XY, actor XY,
	// transition flag, eight participant check/position rows, transition18,
	// state byte and final u32. Client check fields remain opaque.
	if len(p) != 160 {
		return [2]byte{}, fmt.Errorf("room move must contain155 bytes padded to160")
	}
	if e := padding(p[155:], 16); e != nil {
		return [2]byte{}, e
	}
	if p[10] > 1 {
		return [2]byte{}, fmt.Errorf("invalid room transition flag")
	}
	return [2]byte{p[0], p[1]}, nil
}

type DungeonRoomTransition struct {
	Position    [2]byte
	LayerChange bool
	Record      [18]byte
	Dungeon     uint32
	// SceneExit 只由服务端设置：标记这次 layer 切换是「场景房点门」的出口，
	// 方向是回该位置的 base。客户端的 CMD45 永远是 SceneExit=false（前进）。
	SceneExit bool
}

func DecodeDungeonRoomTransition(p []byte) (r DungeonRoomTransition, err error) {
	r.Position, err = DecodeMoveDungeonRoom(p)
	if err != nil {
		return r, err
	}
	if len(p) >= 11 {
		r.LayerChange = p[10] == 1
	}
	if len(p) >= 150 {
		copy(r.Record[:], p[132:150])
	}
	if len(p) >= 155 {
		r.Dungeon = binary.LittleEndian.Uint32(p[151:155])
	}
	return r, nil
}
