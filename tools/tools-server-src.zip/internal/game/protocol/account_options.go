package protocol

import (
	_ "embed"
	"encoding/binary"
	"fmt"
)

// NativeAccountOptions comes from constructor 1475757f0, not a zero table.
// NOTI2826 reads all 3648 bytes. Sparse flags leave other options to the
// client's original UnifiedOption.ctp defaults (merge 147578720).
//
//go:embed templates/account-options-current.bin
var nativeAccountOptions []byte

// RewardGuideOption 是副本选择的掉落奖励引导；实机关闭时上传账号选项 190=1。
const RewardGuideOption uint16 = 190

// DecodeRewardGuideChange 对应原生发送器 0x1403d7770。
// 当前客户端发送 13 字节不参与选项语义的前缀、u8 作用域、u8 分组、u32 数量，
// 再逐项写入 u16 索引和 u16 值；仅处理账号标量分组中的奖励引导。
func DecodeRewardGuideChange(p []byte) (dismissed, present bool, err error) {
	if len(p) < 19 {
		return false, false, fmt.Errorf("统一设置请求长度不足")
	}
	if p[13] != 1 || p[14] != 1 {
		return false, false, nil
	}
	count := binary.LittleEndian.Uint32(p[15:19])
	if count > 286 || uint64(19)+uint64(count)*4 > uint64(len(p)) {
		return false, false, fmt.Errorf("账号设置数量或长度无效")
	}
	end := 19 + int(count)*4
	if err := padding(p[end:], 8); err != nil {
		return false, false, err
	}
	for offset := 19; offset < end; offset += 4 {
		index := binary.LittleEndian.Uint16(p[offset:])
		if index >= 286 {
			return false, false, fmt.Errorf("账号设置索引越界")
		}
		if index != RewardGuideOption {
			continue
		}
		value := binary.LittleEndian.Uint16(p[offset+2:])
		if present || value > 1 {
			return false, false, fmt.Errorf("奖励引导设置重复或值无效")
		}
		dismissed, present = value == 1, true
	}
	return dismissed, present, nil
}

// RestoreRewardGuide 仅覆盖这一项，不重置已有的其他账号设置。
func RestoreRewardGuide(base []byte, dismissed bool) ([]byte, error) {
	if !dismissed {
		return base, nil
	}
	if len(base) == 0 {
		return AccountOptions(map[uint16]uint16{RewardGuideOption: 1})
	}
	if len(base) != len(nativeAccountOptions) {
		return nil, fmt.Errorf("账号设置模板长度错误")
	}
	p := append([]byte(nil), base...)
	p[0] = 1
	binary.LittleEndian.PutUint16(p[2+int(RewardGuideOption)*2:], 1)
	p[574+int(RewardGuideOption)] = 1
	return p, nil
}

func AccountOptions(overrides map[uint16]uint16) ([]byte, error) {
	return MergeAccountOptions(nativeAccountOptions, overrides)
}

// MergeAccountOptions 在当前配置模板上恢复已保存选项，不丢弃其余配置值。
func MergeAccountOptions(base []byte, overrides map[uint16]uint16) ([]byte, error) {
	if len(base) == 0 {
		base = nativeAccountOptions
	}
	if len(base) != 3648 {
		return nil, fmt.Errorf("current account option template size mismatch")
	}
	p := append([]byte(nil), base...)
	for index, value := range overrides {
		if index >= 286 || value == 65535 {
			return nil, fmt.Errorf("invalid account option %d", index)
		}
		p[0] = 1
		binary.LittleEndian.PutUint16(p[2+int(index)*2:], value)
		p[574+int(index)] = 1
	}
	return p, nil
}

// FillAccountHotkeys overlays account-wide hotkey schemes onto the 3648-byte NOTI2826 block.
// Subtype 3 (Scheme A) sits at offset 1277, and Subtype 4 (Scheme B) sits at offset 1750.
func FillAccountHotkeys(block []byte, hotkeys, hotkeysExt map[uint16]uint16) error {
	if len(block) != 3648 {
		return fmt.Errorf("account option block size mismatch: %d != 3648", len(block))
	}
	if len(hotkeys) > 0 {
		if err := FillHotkeysBlock(block[UnifiedAccountHotkeysAt:UnifiedAccountHotkeysAt+UnifiedHotkeysBlockSize], hotkeys); err != nil {
			return err
		}
	}
	if len(hotkeysExt) > 0 {
		if err := FillHotkeysBlock(block[UnifiedAccountHotkeysExtAt:UnifiedAccountHotkeysExtAt+UnifiedHotkeysBlockSize], hotkeysExt); err != nil {
			return err
		}
	}
	return nil
}

