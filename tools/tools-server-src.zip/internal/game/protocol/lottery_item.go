package protocol

import (
	"encoding/binary"
	"fmt"
)

// DecodeLotteryItemUse follows the CMD27 sender: u16 source slot, u32 zero.
// Captured plaintext is 8 bytes because the encrypted block is padded.
func DecodeLotteryItemUse(p []byte) (uint16, error) {
	if len(p) != 6 && len(p) != 8 {
		return 0, fmt.Errorf("lottery use body has %d bytes", len(p))
	}
	slot := binary.LittleEndian.Uint16(p)
	if slot == 0 || slot == 1 {
		return 0, fmt.Errorf("lottery use has invalid source slot")
	}
	for _, b := range p[2:] {
		if b != 0 {
			return 0, fmt.Errorf("lottery use has nonzero reserved data")
		}
	}
	return slot, nil
}

// LotteryItemSuccess 按当前客户端的 CMD27 成功读取顺序编码源槽和奖励行。
// 公共分发器 1459A1BB0 读取成功标志后直接分发，仅失败时读取 u16 错误码；
// 14529EDE0 随后读取 u16 源槽和 181 字节奖励行，成功头不得附带错误码。
// 特定装备类型需要的末尾 u32 由调用方按物品定义追加。
func LotteryItemSuccess(sourceSlot uint16, reward [CurrentItemRecordSize]byte) []byte {
	p := add16([]byte{1}, sourceSlot)
	return append(p, reward[:]...)
}
